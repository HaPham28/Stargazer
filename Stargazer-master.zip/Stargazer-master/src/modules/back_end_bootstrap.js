export function import_client_side(){
    return import("client_side");
}
