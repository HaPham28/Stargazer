# Stargazer
This is the repository for our Stargazing planner project

wasm-pack build (from client side folder)
npm start (from main Stargazer folder)
go to localhost:8080

