use crate::server_connection::{ServerConnection, ServerConnectionResult, set_token};
use packet::{FromClientWrapper, PacketFromClient, PacketFromServer, UsernameOrId, UserPublic, TokenType, UserFull, SearchString, Paging, IdType};
use packet::data::place::Place;
use packet::data::review::Review;

impl ServerConnection{
    pub async fn login(&self, username: String, password: String) -> ServerConnectionResult<()>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::LoginRequest{ username, password }
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::LoginResponse{ auth_token, user } = response_packet{
            set_token(Some((auth_token, Some(user))));
            Ok(())
        }
        else{
            Err(response_packet.into())
        }
    }
    pub async fn change_password(&self, username: String, old_password: String, new_password: String) -> ServerConnectionResult<()>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::ChangePasswordRequest { username, old_password, new_password },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::ChangePasswordResponse { auth_token, user } = response_packet{
            set_token(Some((auth_token, Some(user))));
            Ok(())
        }
        else{
            Err(response_packet.into())
        }
    }
    pub async fn register_user(&self, username: String, email: String, password: String) -> ServerConnectionResult<()>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::RegisterRequest { username, email, password },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::RegisterResponse { token, user } = response_packet{
            set_token(Some((token, Some(user))));
            Ok(())
        }
        else{
            Err(response_packet.into())
        }
    }
    pub async fn delete_user(&self, username: String, password: String) -> ServerConnectionResult<()>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::DeleteUserRequest{ username, password },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::DeleteUserResponse = response_packet{
            Ok(())
        }
        else{
            Err(response_packet.into())
        }
    }

    pub async fn get_user_public_info(&self, user: UsernameOrId) -> ServerConnectionResult<UserPublic>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::UserPublicRequest { user },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::UserPublicResponse { user } = response_packet{
            Ok(user)
        }
        else{
            Err(response_packet.into())
        }
    }
    pub async fn get_user_full_info(&self, token: TokenType) -> ServerConnectionResult<UserFull>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::UserFullRequest { token },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::UserFullResponse { new_token, user } = response_packet{
            set_token(Some((new_token, Some(user.clone()))));
            Ok(user)
        }
        else{
            Err(response_packet.into())
        }
    }
    pub async fn search_user(&self, search_string: SearchString, paging: Paging) -> ServerConnectionResult<Vec<UserPublic>>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::SearchUserRequest { search_string, paging },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::SearchUserResponse { found } = response_packet{
            Ok(found)
        }
        else{
            Err(response_packet.into())
        }
    }

    pub async fn get_place(&self, place_id: String) -> ServerConnectionResult<Place>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::GetPlaceRequest { place_id },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::GetPlaceResponse { place } = response_packet{
            Ok(place)
        }
        else{
            Err(response_packet.into())
        }
    }

    pub async fn add_review(&self, token: TokenType, place_id: String, review: u8, review_text: Option<String>) -> ServerConnectionResult<IdType>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::AddReviewRequest { token, place_id, review, review_text },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::AddReviewResponse { new_token, id } = response_packet{
            set_token(Some((new_token, None)));
            Ok(id)
        }
        else{
            Err(response_packet.into())
        }
    }
    pub async fn delete_review(&self, token: TokenType, review_id: IdType) -> ServerConnectionResult<()>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::DeleteReviewRequest { token, review_id },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::DeleteReviewResponse { new_token } = response_packet{
            set_token(Some((new_token, None)));
            Ok(())
        }
        else{
            Err(response_packet.into())
        }
    }
    pub async fn get_review(&self, review_id: IdType) -> ServerConnectionResult<Review>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::GetReviewRequest { review_id },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::GetReviewResponse { review } = response_packet{
            Ok(review)
        }
        else{
            Err(response_packet.into())
        }
    }
    pub async fn get_reviews_for_user(&self, user: UsernameOrId, paging: Paging) -> ServerConnectionResult<Vec<Review>>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::GetReviewsForUserRequest { user, paging },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::GetReviewsForUserResponse { reviews } = response_packet{
            Ok(reviews)
        }
        else{
            Err(response_packet.into())
        }
    }
    pub async fn get_reviews_for_place(&self, place_id: String, paging: Paging) -> ServerConnectionResult<Vec<Review>>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::GetReviewsForPlaceRequest { place_id, paging },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::GetReviewsForPlaceResponse { reviews } = response_packet{
            Ok(reviews)
        }
        else{
            Err(response_packet.into())
        }
    }

    pub async fn add_favorite_place(&self, token: TokenType, place_id: String) -> ServerConnectionResult<()>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::AddFavoritePlaceRequest { token, place_id },
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::AddFavoritePlaceResponse { new_token } = response_packet{
            set_token(Some((new_token, None)));
            Ok(())
        }
        else{
            Err(response_packet.into())
        }
    }
    pub async fn remove_favorite_place(&self, token: TokenType, place_id: String) -> ServerConnectionResult<()>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::RemoveFavoritePlaceRequest {token, place_id},
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::RemoveFavoritePlaceResponse { new_token } = response_packet{
            set_token(Some((new_token, None)));
            Ok(())
        }
        else{
            Err(response_packet.into())
        }
    }
    pub async fn get_favorite_places(&self, token: TokenType, paging: Paging) -> ServerConnectionResult<Vec<Place>>{
        let response = self.send_packet(FromClientWrapper{
            client_id: self.client_id,
            packet: PacketFromClient::GetFavoritePlacesRequest {token, paging},
        }).await?;
        let response_packet = response.packet?;
        if let PacketFromServer::GetFavoritePlacesResponse { new_token, places} = response_packet{
            set_token(Some((new_token, None)));
            Ok(places)
        }
        else{
            Err(response_packet.into())
        }
    }
}
