pub mod requests;

use wasm_bindgen::prelude::*;
use packet::{SERVER_IP, PORT, FromClientWrapper, FromServerWrapper, IdType, ResponseError, AuthToken, PacketFromServer, UserFull};
use std::fmt;
use std::fmt::Display;
use core::fmt::{Formatter, Debug};
use wasm_bindgen_futures::JsFuture;
use rsa::RSAPublicKey;
use parking_lot::Mutex;
use rand::random;
use web_sys::{Request, RequestInit, RequestMode, Response, Headers};
use wasm_bindgen::JsCast;
use lazy_static::lazy_static;
use once_cell::sync::OnceCell;
use std::ops::DerefMut;

lazy_static!{
    pub static ref URL: String = format!("http://{}:{}/", SERVER_IP, PORT);
    pub static ref KEY_ENDPOINT: String = format!("{}key", *URL);
    pub static ref PACKET_ENDPOINT: String = format!("{}packet", *URL);
}
pub static TOKEN: OnceCell<Mutex<Option<(AuthToken, UserFull)>>> = OnceCell::new();
pub static SERVER_PUBLIC_KEY: OnceCell<Mutex<RSAPublicKey>> = OnceCell::new();

pub(crate) fn set_token(token: Option<(AuthToken, Option<UserFull>)>){
    let mutex = TOKEN.get_or_init(|| Mutex::new(None));
    let mut guard = mutex.lock();
    match token {
        None => *guard.deref_mut() = None,
        Some((token, None)) => {
            if let Some((old_token, _)) = guard.deref_mut(){
                *old_token = token;
            }
            else{
                panic!("Cannot set token without user and having no old user");
            }
        },
        Some((token, Some(user))) => *guard.deref_mut() = Some((token, user)),
    }
}
pub(self) fn set_server_public_key(key: RSAPublicKey){
    match SERVER_PUBLIC_KEY.get() {
        None => SERVER_PUBLIC_KEY.set(Mutex::new(key)).unwrap(),
        Some(mutex) => *mutex.lock().deref_mut() = key,
    }
}

pub struct ServerConnection{
    client_id: IdType,
}
impl ServerConnection{
    pub fn new() -> ServerConnectionResult<ServerConnection>{
        Ok(Self{
            client_id: random(),
        })
    }

    pub(self) async fn send_packet(&self, packet: FromClientWrapper) -> ServerConnectionResult<FromServerWrapper>{
        let data = serde_cbor::to_vec(&packet)?;
        let out = JsValue::from_str(&serde_json::to_string(&data)?);

        let headers = Headers::new()?;
        headers.append("content-type", "application/json")?;
        let mut opts = RequestInit::new();
        opts.method("POST");
        opts.headers(&headers.into());
        opts.body(Some(&out));
        opts.mode(RequestMode::Cors);
        let request = Request::new_with_str_and_init(&PACKET_ENDPOINT, &opts)?;
        let window = web_sys::window().unwrap();
        let resp_value = JsFuture::from(window.fetch_with_request(&request)).await?;
        assert!(resp_value.is_instance_of::<Response>());
        let resp: Response = resp_value.dyn_into().unwrap();
        let json = JsFuture::from(resp.text()?).await?;
        let data_return: Vec<u8> = serde_json::from_str(&json.as_string().unwrap())?;
        let packet_received: FromServerWrapper = serde_cbor::from_slice(&data_return)?;
        // assert_eq!(packet_received.client_id, self.client_id);
        Ok(packet_received)
    }

    pub async fn fetch_server_key() -> ServerConnectionResult<()>{
        let mut opts = RequestInit::new();
        opts.method("GET");
        opts.mode(RequestMode::Cors);
        let request = Request::new_with_str_and_init(&KEY_ENDPOINT, &opts)?;

        let window = web_sys::window().unwrap();
        let resp_value = JsFuture::from(window.fetch_with_request(&request)).await?;
        assert!(resp_value.is_instance_of::<Response>());
        let resp: Response = resp_value.dyn_into().unwrap();
        let json = JsFuture::from(resp.text()?).await?;
        let key: RSAPublicKey = serde_json::from_str(&json.as_string().unwrap())?;
        set_server_public_key(key);
        Ok(())
    }

    //noinspection DuplicatedCode
    // fn get_key() -> ServerConnectionResult<(RSAPrivateKey, RSAPublicKey)>{
    //     let mut rng = thread_rng();
    //     const BITS: usize = 2048;
    //     let priv_key = RSAPrivateKey::new(&mut rng, BITS)?;
    //     let pub_key = RSAPublicKey::from(&priv_key);
    //     Ok((priv_key, pub_key))
    // }
}

pub type ServerConnectionResult<T> = Result<T, ServerConnectionError>;
#[derive(Debug)]
pub enum ServerConnectionError {
    JsValue(JsValue),
    RsaError(rsa::errors::Error),
    SerdeJsonError(serde_json::Error),
    SerdeCborError(serde_cbor::Error),
    ResponseError(ResponseError),
    WrongResponse(PacketFromServer),
    NoToken,
}
impl Display for ServerConnectionError {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        <Self as Debug>::fmt(self, f)
    }
}
impl From<JsValue> for ServerConnectionError{
    fn from(from: JsValue) -> Self {
        Self::JsValue(from)
    }
}
impl From<rsa::errors::Error> for ServerConnectionError{
    fn from(from: rsa::errors::Error) -> Self {
        Self::RsaError(from)
    }
}
impl From<serde_json::Error> for ServerConnectionError{
    fn from(from: serde_json::Error) -> Self {
        Self::SerdeJsonError(from)
    }
}
impl From<serde_cbor::Error> for ServerConnectionError{
    fn from(from: serde_cbor::Error) -> Self {
        Self::SerdeCborError(from)
    }
}
impl From<ResponseError> for ServerConnectionError{
    fn from(from: ResponseError) -> Self {
        Self::ResponseError(from)
    }
}
impl From<PacketFromServer> for ServerConnectionError{
    fn from(from: PacketFromServer) -> Self {
        Self::WrongResponse(from)
    }
}
