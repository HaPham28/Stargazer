#![cfg_attr(not(target_arch = "wasm32"), allow(dead_code))]

use wasm_bindgen::prelude::*;
use crate::server_connection::{ServerConnection, ServerConnectionResult, TOKEN, ServerConnectionError};
use wasm_bindgen_futures::future_to_promise;
use js_sys::{Promise, Array};
use crate::utils::set_panic_hook;
use crate::{console_log, server_connection};
use packet::{UsernameOrId, IdType, AuthToken, UserFull, SearchString, Paging};
use std::ops::Deref;
use std::convert::{TryInto, TryFrom};
use crate::wasm_type::auth_token::JsAuthToken;
use crate::wasm_type::user::{JsUserPublic, JsUserFull};
use crate::wasm_type::place::JsPlace;
use packet::data::place::Place;
use packet::data::review::Review;
use crate::wasm_type::review::JsReview;

#[wasm_bindgen]
pub fn init() -> Promise{
    future_to_promise(async{
        match init_intern().await {
            Ok(_) => Ok(JsValue::undefined()),
            Err(error) => Err(JsValue::from(format!("Init error: {}", error)))
        }
    })
}
async fn init_intern() -> ServerConnectionResult<()>{
    set_panic_hook();
    ServerConnection::fetch_server_key().await?;
    console_log(&"client_side initialized".to_owned());
    Ok(())
}

/// Gets the auth token
#[wasm_bindgen]
pub fn get_token() -> Result<Option<JsAuthToken>, JsValue>{
    match TOKEN.get() {
        None => Ok(None),
        Some(token) => {
            let token_guard = token.lock();
            if let Some(token_val) = token_guard.deref(){
                match JsAuthToken::try_from(token_val){
                    Ok(token) => Ok(Some(token)),
                    Err(error) => Err(JsValue::from(format!("Error: {}", error))),
                }
            }
            else{
                Ok(None)
            }
        }
    }
}
/// Sets the auth token
#[wasm_bindgen]
pub fn set_token(token: Option<JsAuthToken>) -> Result<(), JsValue>{
    match token {
        None => server_connection::set_token(None),
        Some(token) => {
            let (token, user): (AuthToken, UserFull) = match token.try_into(){
                Ok(val) => val,
                Err(error) => return Err(JsValue::from(format!("Error: {}", error))),
            };
            server_connection::set_token(Some((token, Some(user))));
        }
    }

    Ok(())
}

/// Attempts login and sets the auth token if no errors are thrown
#[wasm_bindgen]
pub fn login(username: String, password: String) -> Promise{
    future_to_promise(async{
         match login_intern(username, password).await {
            Err(error) => Err(JsValue::from_str(&format!("Error Logging In: {}", error))),
            Ok(_) => Ok(JsValue::null()),
        }
    })
}
async fn login_intern(username: String, password: String) -> ServerConnectionResult<()>{
    ServerConnection::new()?.login(username, password).await?;
    Ok(())
}
/// Changes password and sets auth token if successful
#[wasm_bindgen]
pub fn change_password(username: String, old_password: String, new_password: String) -> Promise{
    future_to_promise(async{
        match change_password_intern(username, old_password, new_password).await {
            Err(error) => Err(JsValue::from_str(&format!("Error Changing Password: {}", error))),
            Ok(_) => Ok(JsValue::null()),
        }
    })
}
async fn change_password_intern(username: String, old_password: String, new_password: String) -> ServerConnectionResult<()>{
    ServerConnection::new()?.change_password(username, old_password, new_password).await?;
    Ok(())
}
#[wasm_bindgen]
pub fn register_user(username: String, email: String, password: String) -> Promise{
    future_to_promise(async move{
        match register_user_intern(username, email, password).await {
            Ok(_) => Ok(JsValue::null()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
async fn register_user_intern(username: String, email: String, password: String) -> ServerConnectionResult<()>{
    ServerConnection::new()?.register_user(username, email, password).await
}
#[wasm_bindgen]
pub fn delete_user(username: String, password: String) -> Promise{
    future_to_promise(async move{
        match delete_user_intern(username, password).await {
            Ok(_) => Ok(JsValue::null()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
async fn delete_user_intern(username: String, password: String) -> ServerConnectionResult<()>{
    ServerConnection::new()?.delete_user(username, password).await
}

#[wasm_bindgen]
pub fn get_user_public_username(username: String) -> Promise{
    future_to_promise(async move{
        match get_user_public_intern(UsernameOrId::Username(username)).await {
            Ok(user) => Ok(user.into()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
#[wasm_bindgen]
pub fn get_user_public_id(id: IdType) -> Promise{
    future_to_promise(async move{
        match get_user_public_intern(UsernameOrId::Id(id)).await {
            Ok(user) => Ok(user.into()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
async fn get_user_public_intern(user: UsernameOrId) -> ServerConnectionResult<JsUserPublic>{
    Ok(ServerConnection::new()?.get_user_public_info(user).await?.into())
}
#[wasm_bindgen]
pub fn get_user_full() -> Promise{
    future_to_promise(async move{
        match get_user_full_intern().await {
            Ok(user) => Ok(user.into()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
async fn get_user_full_intern() -> ServerConnectionResult<Option<JsUserFull>>{
    match TOKEN.get() {
        None => Err(ServerConnectionError::NoToken),
        Some(token) => {
            match token.lock().deref().clone(){
                None => Ok(None),
                Some(val) => Ok(Some(ServerConnection::new()?.get_user_full_info(val.0.token).await?.into())),
            }
        },
    }

}
#[wasm_bindgen]
pub fn search_user(search_string: String, limit: u32, offset: usize) -> Promise{
    future_to_promise(async move{
        match search_user_intern(SearchString(search_string), Paging{ limit: limit as usize, offset }).await {
            Ok(value) => Ok(value.into()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
async fn search_user_intern(search_string: SearchString, paging: Paging) -> ServerConnectionResult<Array>{
    let results = ServerConnection::new()?.search_user(search_string, paging).await?;
    let out = Array::new_with_length(results.len() as u32);
    for (index, result) in results.into_iter().enumerate(){
        let result_js: JsUserPublic = result.into();
        out.set(index as u32, result_js.into());
    }
    Ok(out)
}

#[wasm_bindgen]
pub fn get_place(place_id: String) -> Promise{
    future_to_promise(async move{
        match get_place_intern(place_id).await {
            Ok(value) => Ok(JsPlace::from(value).into()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
async fn get_place_intern(place_id: String) -> ServerConnectionResult<Place>{
    Ok(ServerConnection::new()?.get_place(place_id).await?.into())
}

#[wasm_bindgen]
pub fn add_review(place_id: String, review: u8, review_text: Option<String>) -> Promise{
    future_to_promise(async move{
        match add_review_intern(place_id, review, review_text).await {
            Ok(value) => Ok(JsValue::from(value as u32)),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
async fn add_review_intern(place_id: String, review: u8, review_text: Option<String>) -> ServerConnectionResult<IdType>{
    let (token, _): (AuthToken, UserFull) = match get_token()?{
        None => return Err(ServerConnectionError::NoToken),
        Some(token) => token.try_into()?,
    };
    Ok(ServerConnection::new()?.add_review(token.token, place_id, review, review_text).await?.into())
}
#[wasm_bindgen]
pub fn delete_review(review_id: IdType) -> Promise{
    future_to_promise(async move{
        match delete_review_intern(review_id).await {
            Ok(_) => Ok(JsValue::null()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
async fn delete_review_intern(review_id: IdType) -> ServerConnectionResult<()>{
    let (token, _): (AuthToken, UserFull) = match get_token()?{
        None => return Err(ServerConnectionError::NoToken),
        Some(token) => token.try_into()?,
    };
    Ok(ServerConnection::new()?.delete_review(token.token, review_id).await?.into())
}
#[wasm_bindgen]
pub fn get_review(review_id: IdType) -> Promise{
    future_to_promise(async move{
        match get_review_intern(review_id).await {
            Ok(value) => Ok(JsReview::from(value).into()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
async fn get_review_intern(review_id: IdType) -> ServerConnectionResult<Review>{
    Ok(ServerConnection::new()?.get_review(review_id).await?)
}
#[wasm_bindgen]
pub fn get_reviews_for_user_username(username: String, limit: u32, offset: usize) -> Promise{
    future_to_promise(async move{
        match get_reviews_for_user_intern(UsernameOrId::Username(username), Paging{ limit: limit as usize, offset }).await {
            Ok(value) => Ok(value.into()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
#[wasm_bindgen]
pub fn get_reviews_for_user_id(id: IdType, limit: u32, offset: usize) -> Promise{
    future_to_promise(async move{
        match get_reviews_for_user_intern(UsernameOrId::Id(id), Paging{ limit: limit as usize, offset }).await {
            Ok(value) => Ok(value.into()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
async fn get_reviews_for_user_intern(user: UsernameOrId, paging: Paging) -> ServerConnectionResult<Array>{
    let results = ServerConnection::new()?.get_reviews_for_user(user, paging).await?;
    let out = Array::new_with_length(results.len() as u32);
    for (index, result) in results.into_iter().enumerate(){
        let result_js: JsReview = result.into();
        out.set(index as u32, result_js.into());
    }
    Ok(out)
}
#[wasm_bindgen]
pub fn get_reviews_for_place(place_id: String, limit: u32, offset: usize) -> Promise{
    future_to_promise(async move{
        match get_reviews_for_place_intern(place_id, Paging{ limit: limit as usize, offset }).await {
            Ok(value) => Ok(value.into()),
            Err(error) => Err(JsValue::from_str(&format!("Error getting user public: {}", error))),
        }
    })
}
async fn get_reviews_for_place_intern(place_id: String, paging: Paging) -> ServerConnectionResult<Array>{
    let results = ServerConnection::new()?.get_reviews_for_place(place_id, paging).await?;
    let out = Array::new_with_length(results.len() as u32);
    for (index, result) in results.into_iter().enumerate(){
        let result_js: JsReview = result.into();
        out.set(index as u32, result_js.into());
    }
    Ok(out)
}

#[wasm_bindgen]
pub fn add_favorite_place(place_id: String) -> Promise{
    future_to_promise(async move{
        match add_favorite_place_intern(place_id).await {
            Ok(_) => Ok(JsValue::null()),
            Err(error) => Err(JsValue::from_str(&format!("Error adding favorite place: {}", error))),
        }
    })
}
async fn add_favorite_place_intern(place_id: String) -> ServerConnectionResult<()>{
    let (token, _): (AuthToken, UserFull) = match get_token()?{
        None => return Err(ServerConnectionError::NoToken),
        Some(token) => token.try_into()?,
    };
    Ok(ServerConnection::new()?.add_favorite_place(token.token, place_id).await?.into())
}
#[wasm_bindgen]
pub fn remove_favorite_place(place_id: String) -> Promise{
    future_to_promise(async move{
        match remove_favorite_place_intern(place_id).await {
            Ok(_) => Ok(JsValue::null()),
            Err(error) => Err(JsValue::from_str(&format!("Error adding favorite place: {}", error))),
        }
    })
}
async fn remove_favorite_place_intern(place_id: String) -> ServerConnectionResult<()>{
    let (token, _): (AuthToken, UserFull) = match get_token()?{
        None => return Err(ServerConnectionError::NoToken),
        Some(token) => token.try_into()?,
    };
    Ok(ServerConnection::new()?.remove_favorite_place(token.token, place_id).await?.into())
}
#[wasm_bindgen]
pub fn get_favorite_places(limit: u32, offset: u32) -> Promise{
    future_to_promise(async move{
        match get_favorite_places_intern(Paging{ limit: limit as usize, offset: offset as usize }).await {
            Ok(val) => Ok(val.into()),
            Err(error) => Err(JsValue::from_str(&format!("Error adding favorite place: {}", error))),
        }
    })
}
async fn get_favorite_places_intern(paging: Paging) -> ServerConnectionResult<Array>{
    let (token, _): (AuthToken, UserFull) = match get_token()?{
        None => return Err(ServerConnectionError::NoToken),
        Some(token) => token.try_into()?,
    };
    let results = ServerConnection::new()?.get_favorite_places(token.token, paging).await?;
    let out = Array::new_with_length(results.len() as u32);
    for (index, result) in results.into_iter().enumerate(){
        let result_js = JsPlace::from(result);
        out.set(index as u32, result_js.into());
    }
    Ok(out)
}
