use wasm_bindgen::prelude::*;
use packet::IdType;
use packet::data::review::Review;

#[wasm_bindgen]
pub struct JsReview {
    user_id: IdType,
    place_id: String,
    review: u8,
    review_text: Option<String>,
}
#[wasm_bindgen]
impl JsReview {
    pub fn new(user_id: IdType, place_id: String, review: u8, review_text: Option<String>) -> Self{
        Self{ user_id, place_id, review, review_text }
    }

    pub fn user_id(&self) -> IdType{
        self.user_id.clone()
    }
    pub fn place_id(&self) -> String{
        self.place_id.clone()
    }
    pub fn review(&self) -> u8{
        self.review.clone()
    }
    pub fn review_text(&self) -> Option<String>{
        self.review_text.clone()
    }
}
impl From<Review> for JsReview{
    fn from(from: Review) -> Self {
        Self{
            user_id: from.user_id,
            place_id: from.place_id,
            review: from.review,
            review_text: from.review_text,
        }
    }
}
