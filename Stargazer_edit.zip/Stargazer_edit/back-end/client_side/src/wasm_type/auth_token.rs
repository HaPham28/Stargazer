use wasm_bindgen::prelude::*;
use packet::{AuthToken, UserFull};
use std::convert::TryFrom;
use serde::{Serialize, Deserialize};

#[wasm_bindgen]
#[derive(Serialize, Deserialize)]
pub struct JsAuthToken{
    token: String,
    expires: String,
    user: String,
}
#[wasm_bindgen]
impl JsAuthToken{
    #[wasm_bindgen(constructor)]
    pub fn new(token: String, expires: String, user: String) -> Self{
        Self{ token, expires, user }
    }

    pub fn token(&self) -> String{
        self.token.clone()
    }
    pub fn expires(&self) -> String{
        self.expires.clone()
    }
    pub fn user(&self) -> String{
        self.user.clone()
    }

    pub fn to_string(&self) -> Result<String, JsValue>{
        match serde_json::to_string(self){
            Ok(value) => Ok(value),
            Err(error) => Err(JsValue::from(error.to_string())),
        }
    }
    pub fn from_string(input: &str) -> Result<JsAuthToken, JsValue>{
        match serde_json::from_str(input) {
            Ok(value) => Ok(value),
            Err(error) => Err(JsValue::from(error.to_string())),
        }
    }
}
impl TryFrom<&(AuthToken, UserFull)> for JsAuthToken{
    type Error = serde_json::Error;

    fn try_from(value: &(AuthToken, UserFull)) -> Result<Self, Self::Error> {
        Ok(Self{
            token: serde_json::to_string(&value.0.token)?,
            expires: serde_json::to_string(&value.0.expires)?,
            user: serde_json::to_string(&value.1)?,
        })
    }
}
impl TryFrom<JsAuthToken> for (AuthToken, UserFull){
    type Error = serde_json::Error;

    fn try_from(value: JsAuthToken) -> Result<Self, Self::Error> {
        Ok((AuthToken{
            token: serde_json::from_str(&value.token)?,
            expires: serde_json::from_str(&value.expires)?,
        }, serde_json::from_str(&value.user)?))
    }
}
