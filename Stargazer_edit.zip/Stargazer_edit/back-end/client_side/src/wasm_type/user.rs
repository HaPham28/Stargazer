use wasm_bindgen::prelude::*;
use packet::{IdType, UserPublic, UserFull};

#[wasm_bindgen]
#[derive(Debug, Clone)]
pub struct JsUserPublic{
    id: IdType,
    username: String,
    review_count: usize,
}
#[wasm_bindgen]
impl JsUserPublic{
    #[wasm_bindgen(constructor)]
    pub fn new(id: IdType, username: String, num_reviews: usize) -> Self{
        Self{ id, username, review_count: num_reviews }
    }

    pub fn id(&self) -> IdType{
        self.id.clone()
    }
    pub fn username(&self) -> String{
        self.username.clone()
    }
    pub fn review_count(&self) -> usize{
        self.review_count.clone()
    }
}
impl From<UserPublic> for JsUserPublic{
    fn from(from: UserPublic) -> Self {
        Self{
            id: from.id,
            username: from.username,
            review_count: from.review_count,
        }
    }
}
impl From<JsUserPublic> for UserPublic{
    fn from(from: JsUserPublic) -> Self {
        Self{
            id: from.id,
            username: from.username,
            review_count: from.review_count,
        }
    }
}

#[wasm_bindgen]
#[derive(Debug, Clone)]
pub struct JsUserFull{
    user: JsUserPublic,
    email: String,
}
#[wasm_bindgen]
impl JsUserFull{
    pub fn new(user: JsUserPublic, email: String) -> Self{
        Self{ user, email }
    }

    pub fn user(&self) -> JsUserPublic{
        self.user.clone()
    }
    pub fn email(&self) -> String{
        self.email.clone()
    }
    pub fn id(&self) -> IdType{
        self.user.id()
    }
    pub fn username(&self) -> String{
        self.user.username()
    }
    pub fn review_count(&self) -> usize{
        self.user.review_count()
    }
}
impl From<UserFull> for JsUserFull{
    fn from(from: UserFull) -> Self {
        Self{
            user: from.user.into(),
            email: from.email,
        }
    }
}
impl From<JsUserFull> for UserFull{
    fn from(from: JsUserFull) -> Self {
        Self{
            user: from.user.into(),
            email: from.email,
        }
    }
}
