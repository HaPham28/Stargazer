use wasm_bindgen::prelude::*;
use packet::place::Place;

#[wasm_bindgen]
pub struct JsPlace{
    place_id: String,
    average_review: Option<f64>,
    review_count: usize,
}
#[wasm_bindgen]
impl JsPlace{
    #[wasm_bindgen(constructor)]
    pub fn new(place_id: String, average_review: Option<f64>, review_count: usize) -> Self{
        Self{ place_id, average_review, review_count }
    }

    pub fn place_id(&self) -> String{
        self.place_id.clone()
    }
    pub fn average_review(&self) -> Option<f64>{
        self.average_review.clone()
    }
    pub fn review_count(&self) -> usize{
        self.review_count.clone()
    }
}
impl From<Place> for JsPlace{
    fn from(from: Place) -> Self {
        Self{
            place_id: from.place_id,
            average_review: from.average_review,
            review_count: from.review_count,
        }
    }
}
