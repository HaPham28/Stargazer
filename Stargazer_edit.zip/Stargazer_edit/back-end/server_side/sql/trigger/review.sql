DROP TRIGGER IF EXISTS review_before_insert;
CREATE TRIGGER review_before_insert
    BEFORE INSERT
    ON review
    FOR EACH ROW
BEGIN
    IF new.review < review_lower_bound() OR new.review > review_upper_bound() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'update check failed on review.review, out of bounds';
    ELSE
        INSERT IGNORE INTO place(place_id) VALUE (new.place_id);
    END IF;
END;

DROP TRIGGER IF EXISTS review_after_insert;
CREATE TRIGGER review_after_insert
    AFTER INSERT
    ON review
    FOR EACH ROW
BEGIN
    UPDATE place
    SET place.average_review = IFNULL(place.average_review, 0) +
                               ((new.review - IFNULL(place.average_review, 0)) /
                                (place.review_count + 1)),
        place.review_count  = place.review_count + 1
    WHERE place.place_id = new.place_id;

    UPDATE user
    SET user.num_reviews = user.num_reviews + 1
    WHERE user.id = new.user_id;
END;

DROP TRIGGER IF EXISTS review_before_update;
CREATE TRIGGER review_before_update
    BEFORE UPDATE
    ON review
    FOR EACH ROW
BEGIN
    IF new.review < review_lower_bound() OR new.review > review_upper_bound() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'update check failed on review.review, out of bounds';
    END IF;
END;

DROP TRIGGER IF EXISTS review_after_update;
CREATE TRIGGER review_after_update
    AFTER UPDATE
    ON review
    FOR EACH ROW
BEGIN
    UPDATE place
    SET place.average_review =
                ((place.review_count * place.average_review) - old.review + new.review) /
                place.review_count
    WHERE place.place_id = new.place_id;
END;

DROP TRIGGER IF EXISTS review_after_delete;
CREATE TRIGGER review_after_delete
    AFTER DELETE
    ON review
    FOR EACH ROW
BEGIN
    SET @review_number = (SELECT place.review_count
                          FROM place
                          WHERE place.place_id = old.place_id);

    IF @review_number = 1 THEN
        UPDATE place
        SET place.average_review = NULL,
            place.review_count  = GREATEST(place.review_count - 1, 0)
        WHERE place.place_id = old.place_id;
    ELSE
        UPDATE place
        SET place.average_review = ((place.review_count * place.average_review) - old.review) /
                                   (place.review_count - 1),
            place.review_count  = GREATEST(place.review_count - 1, 0)
        WHERE place.place_id = old.place_id;
    END IF;

    UPDATE user
    SET user.num_reviews = GREATEST(user.num_reviews - 1, 0)
    WHERE user.id = old.user_id;
END;
