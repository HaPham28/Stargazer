DROP TRIGGER IF EXISTS user_before_delete;
CREATE TRIGGER user_before_delete
    BEFORE DELETE
    ON user
    FOR EACH ROW
BEGIN
    DELETE FROM favorite_places WHERE favorite_places.user_id = old.id;
    DELETE FROM review WHERE review.user_id = old.id;
END;
