DROP FUNCTION IF EXISTS convert_string;
CREATE FUNCTION convert_string(username VARCHAR(32)) RETURNS VARCHAR(32)
    DETERMINISTIC
    NO SQL
BEGIN
    RETURN LOWER(REPLACE(username, '_', '!'));
END;
