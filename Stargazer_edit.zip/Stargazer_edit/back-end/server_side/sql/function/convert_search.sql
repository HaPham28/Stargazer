DROP FUNCTION IF EXISTS convert_search;
# * are single char and % are multiple char
CREATE FUNCTION convert_search(username VARCHAR(32)) RETURNS VARCHAR(32)
    DETERMINISTIC
    NO SQL
BEGIN
    RETURN REPLACE(username, '*', '_');
END;
