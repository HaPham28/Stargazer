DROP PROCEDURE IF EXISTS update_review_values;
CREATE
    DEFINER = full@localhost PROCEDURE update_review_values()
BEGIN
    # noinspection SqlWithoutWhere
    UPDATE place
        INNER JOIN (
            SELECT review.place_id as place_id,
                   COUNT(*) as count,
                   AVG(review.review) as average
            FROM review
            GROUP BY review.place_id)
            counts ON counts.place_id = place.place_id
    SET place.review_count  = counts.count,
        place.average_review = counts.average;

    UPDATE place
    SET place.review_count = 0,
        place.average_review = NULL
    WHERE place.place_id NOT IN (SELECT review.place_id FROM review GROUP BY review.place_id);
END ;
