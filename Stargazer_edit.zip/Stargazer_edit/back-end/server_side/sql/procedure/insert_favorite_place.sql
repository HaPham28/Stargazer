DROP PROCEDURE IF EXISTS insert_favorite_place;
CREATE PROCEDURE insert_favorite_place(IN in_user_id INT UNSIGNED,
                                       IN in_place_id VARCHAR(128))
BEGIN
    INSERT INTO favorite_places(user_id, place_id)
        VALUE (in_user_id, in_place_id);
END;
