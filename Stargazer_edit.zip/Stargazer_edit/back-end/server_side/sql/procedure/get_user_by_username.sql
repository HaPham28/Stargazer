DROP PROCEDURE IF EXISTS get_user_by_username;
CREATE
    DEFINER = full@localhost PROCEDURE get_user_by_username(IN in_username varchar(32))
BEGIN
    SELECT user.id,
           user.username,
           user.password_hash,
           user.email,
           user.num_reviews
    FROM user
    WHERE user.username = convert_string(in_username);
END;
