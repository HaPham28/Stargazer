DROP PROCEDURE IF EXISTS get_review;
CREATE PROCEDURE get_review(IN in_review_id INT UNSIGNED)
BEGIN
    SELECT review.id,
           review.user_id,
           review.place_id,
           review.review,
           review.review_text,
           user.username
    FROM review
             INNER JOIN user ON review.user_id = user.id
    WHERE review.id = in_review_id;
END;
