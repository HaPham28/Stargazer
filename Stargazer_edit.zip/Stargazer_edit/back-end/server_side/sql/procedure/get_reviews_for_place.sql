DROP PROCEDURE IF EXISTS get_reviews_for_place;
CREATE PROCEDURE get_reviews_for_place(IN in_place_id VARCHAR(128),
                                       IN in_limit INT UNSIGNED,
                                       IN in_offset INT UNSIGNED)
BEGIN
    SELECT review.id,
           review.user_id,
           review.place_id,
           review.review,
           review.review_text,
           user.username
    FROM review
             JOIN user ON review.user_id = user.id
    WHERE review.place_id = in_place_id
    ORDER BY review.id
    LIMIT in_limit OFFSET in_offset;
END;
