DROP PROCEDURE IF EXISTS get_favorite_places;
CREATE PROCEDURE get_favorite_places(IN in_user_id INT UNSIGNED,
                                       IN in_limit INT UNSIGNED,
                                       IN in_offset INT UNSIGNED)
BEGIN
    SELECT place.place_id,
           place.average_review,
           place.review_count
    FROM favorite_places
    INNER JOIN place ON favorite_places.place_id = place.place_id
    WHERE favorite_places.user_id = in_user_id
    LIMIT in_limit OFFSET in_offset;
END;
