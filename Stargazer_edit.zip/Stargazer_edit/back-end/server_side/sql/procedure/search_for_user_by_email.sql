DROP PROCEDURE IF EXISTS search_for_user_by_email;
CREATE PROCEDURE search_for_user_by_email(IN in_search_email VARCHAR(321),
                                          IN in_limit INT UNSIGNED,
                                          IN in_offset INT UNSIGNED)
BEGIN
    SELECT user.id,
           user.username,
           user.password_hash,
           user.email,
           user.num_reviews
    FROM user
    WHERE user.email LIKE convert_search(convert_string(in_search_email))
    ORDER BY user.id
    LIMIT in_limit OFFSET in_offset;
END;
