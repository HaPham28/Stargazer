DROP PROCEDURE IF EXISTS delete_review;
CREATE PROCEDURE delete_review(IN in_id INT UNSIGNED)
BEGIN
    DELETE
    FROM review
    WHERE review.id = in_id;
END;
