DROP PROCEDURE IF EXISTS get_reviews_for_user_by_id;
CREATE PROCEDURE get_reviews_for_user_by_id(IN in_user_id INT UNSIGNED,
                                            IN in_limit INT UNSIGNED,
                                            IN in_offset INT UNSIGNED)
BEGIN
    SELECT review.id,
           review.user_id,
           review.place_id,
           review.review,
           review.review_text,
           user.username
    FROM review
             INNER JOIN user ON review.user_id = user.id
    WHERE review.user_id = in_user_id
    ORDER BY review.id
    LIMIT in_limit OFFSET in_offset;
END;
