DROP PROCEDURE IF EXISTS insert_user;
CREATE PROCEDURE insert_user(IN in_username VARCHAR(32),
                             IN in_password_hash CHAR(90),
                             IN in_email VARCHAR(320))
BEGIN
    INSERT INTO user(username, password_hash, email)
        VALUE (
               convert_string(in_username),
               in_password_hash,
               convert_string(in_email)
        );

    SELECT user.id,
           user.username,
           user.password_hash,
           user.email,
           user.num_reviews
    FROM user
    WHERE user.id = LAST_INSERT_ID();
END;
