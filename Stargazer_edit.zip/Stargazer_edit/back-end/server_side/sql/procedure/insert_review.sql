DROP PROCEDURE IF EXISTS insert_review;
CREATE PROCEDURE insert_review(IN in_user_id INT UNSIGNED,
                               IN in_place_id VARCHAR(128),
                               IN in_review INT UNSIGNED,
                               IN in_review_text TEXT)
BEGIN
    INSERT INTO review(user_id, place_id, review, review_text)
        VALUE (in_user_id, in_place_id, in_review, in_review_text);

    SELECT review.id,
           review.user_id,
           review.place_id,
           review.review,
           review.review_text,
           user.username
    FROM review
    INNER JOIN user ON review.user_id = user.id
    WHERE review.id = LAST_INSERT_ID();
END;
