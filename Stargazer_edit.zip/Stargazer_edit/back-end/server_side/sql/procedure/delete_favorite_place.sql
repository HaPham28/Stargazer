DROP PROCEDURE IF EXISTS delete_favorite_place;
CREATE PROCEDURE delete_favorite_place(IN in_user_id INT UNSIGNED,
                                       IN in_place_id VARCHAR(128))
BEGIN
    DELETE
    FROM favorite_places
    WHERE favorite_places.user_id = in_user_id AND favorite_places.place_id = in_place_id;
END;
