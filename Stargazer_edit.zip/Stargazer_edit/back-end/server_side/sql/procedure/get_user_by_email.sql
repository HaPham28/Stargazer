DROP PROCEDURE IF EXISTS get_user_by_email;
CREATE PROCEDURE get_user_by_email(IN in_email VARCHAR(320))
BEGIN
    SELECT user.id,
           user.username,
           user.password_hash,
           user.email,
           user.num_reviews
    FROM user
    WHERE user.email = convert_string(in_email);
END;
