DROP PROCEDURE IF EXISTS search_for_user_by_username;
CREATE PROCEDURE search_for_user_by_username(IN in_search_string VARCHAR(33),
                                             IN in_limit INT UNSIGNED,
                                             IN in_offset INT UNSIGNED)
BEGIN
    SELECT user.id,
           user.username,
           user.password_hash,
           user.email,
           user.num_reviews
    FROM user
    WHERE user.username LIKE convert_search(convert_string(in_search_string))
    ORDER BY user.id
    LIMIT in_limit OFFSET in_offset;
END;
