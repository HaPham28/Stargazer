DROP PROCEDURE IF EXISTS delete_user_by_username;
CREATE PROCEDURE delete_user_by_username(IN in_username VARCHAR(32))
BEGIN
    DELETE
    FROM user
    WHERE user.username = convert_string(in_username);
END;
