DROP PROCEDURE IF EXISTS get_user_by_id;
CREATE PROCEDURE get_user_by_id(IN in_id INT UNSIGNED)
BEGIN
    SELECT user.id,
           user.username,
           user.password_hash,
           user.email,
           user.num_reviews
    FROM user
    WHERE user.id = in_id;
END;
