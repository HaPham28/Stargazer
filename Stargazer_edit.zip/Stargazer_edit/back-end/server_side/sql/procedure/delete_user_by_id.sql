DROP PROCEDURE IF EXISTS delete_user_by_id;
CREATE PROCEDURE delete_user_by_id(IN in_id INT UNSIGNED)
BEGIN
    DELETE
    FROM user
    WHERE user.id = in_id;
END;
