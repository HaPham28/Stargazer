DROP PROCEDURE IF EXISTS change_user_password;
CREATE PROCEDURE change_user_password(IN in_id INT UNSIGNED,
                                      IN in_password_hash CHAR(90))
BEGIN
    UPDATE user
    SET user.password_hash = in_password_hash
    WHERE user.id = in_id;
END;
