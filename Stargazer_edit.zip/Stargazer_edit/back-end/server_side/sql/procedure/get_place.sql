DROP PROCEDURE IF EXISTS get_place;
CREATE PROCEDURE get_place(IN in_place_id VARCHAR(128))
BEGIN
    INSERT IGNORE INTO place (place_id) VALUE (in_place_id);

    SELECT place.place_id,
           place.average_review,
           place.review_count
    FROM place
    WHERE place.place_id = in_place_id;
END;
