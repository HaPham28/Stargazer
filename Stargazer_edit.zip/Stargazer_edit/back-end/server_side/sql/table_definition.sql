CREATE TABLE place
(
    place_id       VARCHAR(128)             NOT NULL PRIMARY KEY,
    average_review DOUBLE                   NULL,
    review_number  INT UNSIGNED DEFAULT '0' NOT NULL
);

CREATE TABLE user
(
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(32)              NOT NULL,
    password_hash CHAR(90)                 NOT NULL,
    email         VARCHAR(320)             NOT NULL,
    num_reviews   INT UNSIGNED DEFAULT '0' NOT NULL,
    CONSTRAINT user_email_uindex UNIQUE (email),
    CONSTRAINT user_username_uindex UNIQUE (username)
);

CREATE TABLE review
(
    id          INT UNSIGNED AUTO_INCREMENT
        PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    place_id    VARCHAR(128) NOT NULL,
    review      INT UNSIGNED NOT NULL,
    review_text TEXT         NULL,
    CONSTRAINT review_place_place_id_fk FOREIGN KEY (place_id) REFERENCES place (place_id),
    CONSTRAINT review_user_id_fk FOREIGN KEY (user_id) REFERENCES user (id)
);

CREATE TABLE favorite_places
(
    user_id  INT UNSIGNED NOT NULL,
    place_id VARCHAR(128) NOT NULL,
    CONSTRAINT favorite_places_place_place_id_fk FOREIGN KEY (place_id) REFERENCES place (place_id),
    CONSTRAINT favorite_places_user_id_fk FOREIGN KEY (user_id) REFERENCES user (id)
);

CREATE UNIQUE INDEX favorite_places_user_id_place_id_uindex ON favorite_places (user_id, place_id);
