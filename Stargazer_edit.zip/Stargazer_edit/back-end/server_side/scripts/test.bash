#!/bin/bash

export RUST_BACKTRACE=full
cargo test --manifest-path ../Cargo.toml --bin server_side --package server_side
