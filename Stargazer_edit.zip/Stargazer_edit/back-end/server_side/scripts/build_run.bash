#!/bin/bash

export RUST_BACKTRACE=full
./build_debug.bash
./run.bash
