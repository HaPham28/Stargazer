#!/bin/bash

cargo build --manifest-path ../Cargo.toml --bin server_side
