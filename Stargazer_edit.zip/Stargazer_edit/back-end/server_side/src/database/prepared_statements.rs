use mysql::{PooledConn, Statement, Value};
use mysql::prelude::{Queryable, FromRow};
use strum::{EnumCount, IntoEnumIterator};

use crate::database::*;
use crate::database::procedure::Procedure;
use crate::database::user::DatabaseUser;
use crate::AsyncMutex;
use tokio::task::{block_in_place, spawn_blocking};
use publicsuffix::List;
pub use publicsuffix::errors::Result as EmailResult;
use once_cell::sync::OnceCell;
use packet::{IdType, Paging, UsernameOrIdRef};
use crate::database::place::DatabasePlace;
use crate::database::review::DatabaseReview;

static EMAIL_LIST: OnceCell<List> = OnceCell::new();

#[derive(Debug)]
pub struct PreparedStatements(AsyncMutex<PreparedStatementsInner>);
impl PreparedStatements {
    pub fn new(connection: PooledConn) -> DatabaseResult<Self> {
        Ok(Self(AsyncMutex::new(PreparedStatementsInner::new(connection)?)))
    }

    pub async fn change_user_password(&self, id: IdType, password_hash: &str) -> DatabaseResult<()> {
        self.0.lock().await.run_procedure_drop(Procedure::ChangeUserPassword, vec![
            ("id", id.into()),
            ("password_hash", password_hash.into()),
        ]).await
    }
    pub async fn delete_favorite_place(&self, user_id: IdType, place_id: String) -> DatabaseResult<()>{
        self.0.lock().await.run_procedure_drop(Procedure::DeleteFavoritePlace, vec![
            ("user_id", user_id.into()),
            ("place_id", place_id.into()),
        ]).await
    }
    pub async fn delete_review(&self, id: IdType) -> DatabaseResult<()> {
        self.0.lock().await.run_procedure_drop(Procedure::DeleteReview, vec![
            ("id", id.into())
        ]).await
    }
    pub async fn delete_user(&self, user: UsernameOrIdRef<'_>) -> DatabaseResult<()> {
        match user {
            UsernameOrIdRef::Username(username) => self.0.lock().await.run_procedure_drop(Procedure::DeleteUserByUsername, vec![
                ("username", username.into())
            ]).await,
            UsernameOrIdRef::Id(id) => self.0.lock().await.run_procedure_drop(Procedure::DeleteUserById, vec![
                ("id", id.into())
            ]).await,
        }
    }
    pub async fn get_favorite_places(&self, user_id: IdType, paging: Paging) -> DatabaseResult<Vec<DatabasePlace>>{
        self.0.lock().await.run_procedure(Procedure::GetFavoritePlaces, vec![
            ("user_id", user_id.into()),
            ("limit", paging.limit.into()),
            ("offset", paging.offset.into()),
        ]).await
    }
    pub async fn get_place(&self, place_id: String) -> DatabaseResult<DatabasePlace> {
        match self.0.lock().await.run_procedure_first(Procedure::GetPlace, vec![
            ("place_id", place_id.into())
        ]).await?{
            Some(value) => Ok(value),
            None => Err(DatabaseError::NoResults),
        }
    }
    pub async fn get_review(&self, review_id: IdType) -> DatabaseResult<DatabaseReview>{
        match self.0.lock().await.run_procedure_first(Procedure::GetReview, vec![
            ("review_id", review_id.into())
        ]).await?{
            Some(value) => Ok(value),
            None => Err(DatabaseError::NoResults),
        }
    }
    pub async fn get_reviews_for_place(&self, place_id: String, paging: Paging) -> DatabaseResult<Vec<DatabaseReview>>{
        self.0.lock().await.run_procedure(Procedure::GetReviewsForPlace, vec![
            ("place_id", place_id.into()),
            ("limit", paging.limit.into()),
            ("offset", paging.offset.into()),
        ]).await
    }
    pub async fn get_reviews_for_user(&self, user: UsernameOrIdRef<'_>, paging: Paging) -> DatabaseResult<Vec<DatabaseReview>>{
        match user {
            UsernameOrIdRef::Username(username) => self.0.lock().await.run_procedure(Procedure::GetReviewsForUserByUsername, vec![
                ("username", username.into()),
                ("limit", paging.limit.into()),
                ("offset", paging.offset.into()),
            ]).await,
            UsernameOrIdRef::Id(id) => self.0.lock().await.run_procedure(Procedure::GetReviewsForUserById, vec![
                ("user_id", id.into()),
                ("limit", paging.limit.into()),
                ("offset", paging.offset.into()),
            ]).await,
        }
    }
    pub async fn get_user_by_email(&self, email: &str) -> DatabaseResult<Option<DatabaseUser>> {
        self.0.lock().await.run_procedure_first(Procedure::GetUserByEmail, vec![
            ("email", email.into()),
        ]).await
    }
    pub async fn get_user(&self, user: UsernameOrIdRef<'_>) -> DatabaseResult<Option<DatabaseUser>> {
        match user{
            UsernameOrIdRef::Username(username) => self.0.lock().await.run_procedure_first(Procedure::GetUserByUsername, vec![
                ("username", username.into()),
            ]).await,
            UsernameOrIdRef::Id(id) => self.0.lock().await.run_procedure_first(Procedure::GetUserById, vec![
                ("id", id.into()),
            ]).await,
        }
    }
    pub async fn insert_favorite_place(&self, user_id: IdType, place_id: String) -> DatabaseResult<()>{
        self.0.lock().await.run_procedure_drop(Procedure::InsertFavoritePlace, vec![
            ("user_id", user_id.into()),
            ("place_id", place_id.into()),
        ]).await
    }
    pub async fn insert_review(&self, user_id: IdType, place_id: String, review: u8, review_text: Option<String>) -> DatabaseResult<DatabaseReview>{
        match self.0.lock().await.run_procedure_first(Procedure::InsertReview, vec![
            ("user_id", user_id.into()),
            ("place_id", place_id.into()),
            ("review", review.into()),
            ("review_text", review_text.into()),
        ]).await?{
            Some(value) => Ok(value),
            None => Err(DatabaseError::NoResults),
        }
    }
    pub async fn insert_user(&self, username: &str, password_hash: &str, email: &str) -> DatabaseResult<DatabaseUser> {
        PreparedStatementsInner::verify_username(username)?;
        PreparedStatementsInner::verify_email(email).await?;
        match self.0.lock().await.run_procedure_first(Procedure::InsertUser, vec![
            ("username", username.into()),
            ("password_hash", password_hash.into()),
            ("email", email.into()),
        ]).await? {
            Some(value) => Ok(value),
            None => Err(DatabaseError::NoResults),
        }
    }
    pub async fn search_for_user_by_email(&self, search_email: String, paging: Paging) -> DatabaseResult<Vec<DatabaseUser>> {
        self.0.lock().await.run_procedure(Procedure::SearchForUserByEmail, vec![
            ("search_email", search_email.into()),
            ("limit", paging.limit.into()),
            ("offset", paging.offset.into()),
        ]).await
    }
    pub async fn search_for_user_by_username(&self, search_string: &str, paging: Paging) -> DatabaseResult<Vec<DatabaseUser>> {
        self.0.lock().await.run_procedure(Procedure::SearchForUserByUsername, vec![
            ("search_string", search_string.into()),
            ("limit", paging.limit.into()),
            ("offset", paging.offset.into()),
        ]).await
    }
    pub async fn update_review_values(&self) -> DatabaseResult<()>{
        self.0.lock().await.run_procedure_drop::<String>(Procedure::UpdateReviewValues, vec![]).await
    }
}

#[derive(Debug)]
pub struct PreparedStatementsInner {
    connection: PooledConn,
    procedures: Vec<Statement>,
}
impl PreparedStatementsInner {
    fn new(mut connection: PooledConn) -> DatabaseResult<Self> {
        let mut procedures = Vec::with_capacity(Procedure::COUNT);
        for procedure in Procedure::iter() {
            assert_eq!(procedure as usize, procedures.len());
            procedures.push(connection.prep(procedure.query())?);
        }
        Ok(Self {
            connection,
            procedures,
        })
    }

    async fn run_procedure<T: FromRow, N>(&mut self, procedure: Procedure, params: Vec<(N, Value)>) -> DatabaseResult<Vec<T>> where String: From<N> {
        let procedure = self.procedures[procedure as usize].clone();
        block_in_place(move || {
            Ok(self.connection.exec(&procedure, params)?)
        })
    }
    async fn run_procedure_drop<N>(&mut self, procedure: Procedure, params: Vec<(N, Value)>) -> DatabaseResult<()> where String: From<N> {
        let procedure = self.procedures[procedure as usize].clone();
        block_in_place(move || {
            Ok(self.connection.exec_drop(&procedure, params)?)
        })
    }
    async fn run_procedure_first<T: FromRow, N>(&mut self, procedure: Procedure, params: Vec<(N, Value)>) -> DatabaseResult<Option<T>> where String: From<N> {
        let procedure = self.procedures[procedure as usize].clone();
        block_in_place(move || {
            Ok(self.connection.exec_first(&procedure, params)?)
        })
    }

    pub fn verify_username(username: &str) -> UsernameResult<()> {
        if username.len() > MAX_USERNAME_LENGTH {
            return Err(UsernameError::TooLong { length: username.len(), max_length: MAX_USERNAME_LENGTH });
        }
        for char in username.chars() {
            if !VALID_USERNAME_CHARS.contains(&char) {
                return Err(UsernameError::InvalidChar(char));
            }
        }
        Ok(())
    }
    pub async fn verify_email(email: &str) -> DatabaseResult<()> {
        let list = spawn_blocking(|| {
            EMAIL_LIST.get_or_try_init(|| List::fetch())
        }).await??;
        list.parse_email(email)?;
        Ok(())
    }
}


#[cfg(test)]
mod test {
    use std::sync::atomic::{AtomicUsize, Ordering};

    use rand::thread_rng;

    use crate::database::{DatabaseManager, DatabaseResult};
    use crate::database::prepared_statements::PreparedStatements;
    use crate::password::{hash_password, verify_password};
    use crate::password::test::gen_password;
    use packet::{IdType, Paging, UsernameOrIdRef};

    const TEST_USERNAME_PREFIX: &'static str = "test_user";
    static TEST_USERNAME_POSTFIX: AtomicUsize = AtomicUsize::new(0);

    fn get_test_username() -> String {
        format!("{}{}", TEST_USERNAME_PREFIX, TEST_USERNAME_POSTFIX.fetch_add(1, Ordering::SeqCst))
    }

    ///Returns (UserCleaner, id, password)
    async fn insert_test_user(statements: PreparedStatements) -> DatabaseResult<(UserCleaner, IdType, String)> {
        let username = get_test_username();
        if let Some(user) = statements.get_user(UsernameOrIdRef::Username(&username)).await? {
            statements.delete_user((&user).into()).await?;
        }
        let password = gen_password(&mut thread_rng());
        let user = statements.insert_user(&username, &hash_password(&password)?, &format!("{}@gmail.com", username)).await?;
        Ok((UserCleaner { statements, username, clean: false }, user.id, password))
    }

    struct UserCleaner {
        statements: PreparedStatements,
        username: String,
        clean: bool,
    }
    impl UserCleaner {
        async fn clean_up(mut self) {
            self.statements.delete_user(UsernameOrIdRef::Username(&self.username)).await.expect(&format!("Could not delete user {}", self.username));
            self.clean = true;
        }
    }
    impl Drop for UserCleaner {
        fn drop(&mut self) {
            if !self.clean {
                panic!("Users were not cleaned!");
            }
        }
    }

    #[tokio::test(threaded_scheduler)]
    async fn test_delete_user_by_id() {
        let manager = DatabaseManager::new().expect("Error creating manager");
        let statements = manager.prepare_statements().expect("Error preparing statements");
        let (cleaner, id, _) = insert_test_user(statements).await.expect("Error inserting test user");
        cleaner.statements.delete_user(UsernameOrIdRef::Id(id)).await.expect("Error deleting user");
        cleaner.clean_up().await;
    }

    #[tokio::test(threaded_scheduler)]
    async fn test_delete_user_by_username() {
        let manager = DatabaseManager::new().expect("Error creating manager");
        let statements = manager.prepare_statements().expect("Error preparing statements");
        let (cleaner, _, _) = insert_test_user(statements).await.expect("Error inserting test user");
        cleaner.statements.delete_user(UsernameOrIdRef::Username(&cleaner.username)).await.expect("Error deleting user");
        cleaner.clean_up().await;
    }

    #[tokio::test(threaded_scheduler)]
    async fn test_get_user_by_id() {
        let manager = DatabaseManager::new().expect("Error creating manager");
        let statements = manager.prepare_statements().expect("Error preparing statements");
        let (cleaner, id, password) = insert_test_user(statements).await.expect("Error inserting test user");
        let user = cleaner.statements.get_user(UsernameOrIdRef::Id(id)).await.expect("Error getting user").expect("User not found");
        verify_password(&password, &user.password_hash).expect("Error verifying password");
        cleaner.clean_up().await;
    }

    #[tokio::test(threaded_scheduler)]
    async fn test_get_user_by_username() {
        let manager = DatabaseManager::new().expect("Error creating manager");
        let statements = manager.prepare_statements().expect("Error preparing statements");
        let (cleaner, _, password) = insert_test_user(statements).await.expect("Error inserting test user");
        let user = cleaner.statements.get_user(UsernameOrIdRef::Username(&cleaner.username)).await.expect("Error getting user").expect("User not found");
        verify_password(&password, &user.password_hash).expect("Error verifying password");
        cleaner.clean_up().await;
    }

    #[tokio::test(threaded_scheduler)]
    async fn test_search_for_user_by_username() {
        let manager = DatabaseManager::new().expect("Error creating manager");
        let mut users = Vec::with_capacity(10);
        for _ in 0..users.capacity() {
            users.push(insert_test_user(manager.prepare_statements().expect("Error preparing statements")).await.expect("Error inserting user"));
        }
        let statements = manager.prepare_statements().expect("Error preparing statements");
        let found = statements.search_for_user_by_username(&("%".to_owned() + TEST_USERNAME_PREFIX + "%"), Paging { limit: usize::max_value(), offset: 0 }).await.expect("Error searching for tests");
        for user in &found {
            let user = statements.get_user(UsernameOrIdRef::Id(user.id)).await.expect("Error getting user by id").expect("User not found");
            if !user.username.contains(TEST_USERNAME_PREFIX) {
                panic!("Username {} does not contain {}", user.username, TEST_USERNAME_PREFIX);
            }
        }
        for tuple in users.iter() {
            if let None = found.iter().filter(|user| user.id == tuple.1).next() {
                panic!("Id {} not found", tuple.1);
            }
        }

        for user in users {
            user.0.clean_up().await;
        }
    }
}
