use strum_macros::{EnumCount, EnumIter as IntoEnumIterator};

#[derive(Debug, Copy, Clone, Eq, PartialEq, Hash, IntoEnumIterator, EnumCount)]
pub(super) enum Procedure {
    ChangeUserPassword,
    DeleteFavoritePlace,
    DeleteReview,
    DeleteUserById,
    DeleteUserByUsername,
    GetFavoritePlaces,
    GetPlace,
    GetReview,
    GetReviewsForPlace,
    GetReviewsForUserById,
    GetReviewsForUserByUsername,
    GetUserByEmail,
    GetUserById,
    GetUserByUsername,
    InsertFavoritePlace,
    InsertReview,
    InsertUser,
    SearchForUserByEmail,
    SearchForUserByUsername,
    UpdateReviewValues,
}
impl Procedure {
    pub(super) const fn query(&self) -> &'static str {
        match self {
            Self::ChangeUserPassword => "CALL change_user_password(:id, :password_hash)",
            Self::DeleteFavoritePlace => "CALL delete_favorite_place(:user_id, :place_id)",
            Self::DeleteReview => "CALL delete_review(:id)",
            Self::DeleteUserById => "CALL delete_user_by_id(:id)",
            Self::DeleteUserByUsername => "CALL delete_user_by_username(:username)",
            Self::GetFavoritePlaces => "CALL get_favorite_places(:user_id, :limit, :offset)",
            Self::GetPlace => "Call get_place(:place_id)",
            Self::GetReview => "CALL get_review(:review_id)",
            Self::GetReviewsForPlace => "CALL get_reviews_for_place(:place_id, :limit, :offset)",
            Self::GetReviewsForUserById => "CALL get_reviews_for_user_by_id(:user_id, :limit, :offset)",
            Self::GetReviewsForUserByUsername => "CALL get_reviews_for_user_by_username(:username, :limit, :offset)",
            Self::GetUserByEmail => "Call get_user_by_email(:email)",
            Self::GetUserById => "CALL get_user_by_id(:id)",
            Self::GetUserByUsername => "CALL get_user_by_username(:username)",
            Self::InsertFavoritePlace => "CALL insert_favorite_place(:user_id, :place_id)",
            Self::InsertReview => "CALL insert_review(:user_id, :place_id, :review, :review_text)",
            Self::InsertUser => "CALL insert_user(:username, :password_hash, :email)",
            Self::SearchForUserByEmail => "CALL search_for_user_by_email(:search_email, :limit, :offset)",
            Self::SearchForUserByUsername => "CALL search_for_user_by_username(:search_string, :limit, :offset)",
            Self::UpdateReviewValues => "CALL update_review_values()",
        }
    }
}
