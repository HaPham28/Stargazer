use packet::IdType;
use mysql::prelude::FromRow;
use mysql::{FromRowError, Row};
use packet::data::review::Review;
use crate::database::take_from_row;

pub struct DatabaseReview{
    pub id: IdType,
    pub user_id: IdType,
    pub place_id: String,
    pub review: u8,
    pub review_text: Option<String>,
    pub username: String,
}
impl FromRow for DatabaseReview{
    fn from_row_opt(row: Row) -> Result<Self, FromRowError> where Self: Sized {
        let (id, row) = take_from_row(0, row)?;
        let (user_id, row) = take_from_row(1, row)?;
        let (place_id, row) = take_from_row(2, row)?;
        let (review, row) = take_from_row(3, row)?;
        let (review_text, row) = take_from_row(4, row)?;
        let (username, _) = take_from_row(5, row)?;
        Ok(Self{ id, user_id, place_id, review, review_text, username })
    }
}
impl From<DatabaseReview> for Review{
    fn from(from: DatabaseReview) -> Self {
        Self{
            user_id: from.user_id,
            place_id: from.place_id,
            review: from.review,
            review_text: from.review_text,
        }
    }
}
