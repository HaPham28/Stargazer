use mysql::prelude::FromRow;
use mysql::{FromRowError, Row};
use crate::database::take_from_row;
use packet::data::place::Place;

pub struct DatabasePlace{
    pub place_id: String,
    pub average_review: Option<f64>,
    pub review_count: usize,
}
impl FromRow for DatabasePlace{
    fn from_row_opt(row: Row) -> Result<Self, FromRowError> where
        Self: Sized {
        let (place_id, row) = take_from_row(0, row)?;
        let (average_review, row) = take_from_row(1, row)?;
        let (review_count, _) = take_from_row(2, row)?;
        Ok(Self{ place_id, average_review, review_count })
    }
}
impl From<DatabasePlace> for Place{
    fn from(from: DatabasePlace) -> Self {
        Self{
            place_id: from.place_id,
            average_review: from.average_review,
            review_count: from.review_count,
        }
    }
}
