pub mod place;
pub mod prepared_statements;
pub mod procedure;
pub mod review;
pub mod user;

use std::error::Error;
use std::fmt;
use std::fmt::Display;
use lazy_static::lazy_static;
use mysql::{OptsBuilder, Pool, Row, FromRowError};
use mysql::serde::export::fmt::Debug;
use mysql::serde::export::Formatter;
use crate::credentials::full;
use crate::database::prepared_statements::PreparedStatements;
use crate::password::PasswordError;
use tokio::task::JoinError;
use mysql::prelude::FromValue;

#[derive(Debug)]
pub struct DatabaseManager {
    pool: Pool,
}
impl DatabaseManager {
    pub fn new() -> DatabaseResult<DatabaseManager> {
        Ok(DatabaseManager {
            pool: Pool::new_manual(0, 100, OptsBuilder::new()
                .ip_or_hostname(Some("localhost"))
                .db_name(Some("project3"))
                .user(Some(full::USERNAME))
                .pass(Some(full::PASSWORD)))?,
        })
    }

    pub fn prepare_statements(&self) -> DatabaseResult<PreparedStatements> {
        PreparedStatements::new(self.pool.get_conn()?)
    }
}

pub type DatabaseResult<T> = Result<T, DatabaseError>;

#[derive(Debug)]
pub enum DatabaseError {
    MySQLError(mysql::Error),
    PasswordError(PasswordError),
    UsernameError(UsernameError),
    JoinError(JoinError),
    EmailError(String), //Public suffix error not sync
    NoResults,
}
impl From<mysql::Error> for DatabaseError {
    fn from(from: mysql::Error) -> Self {
        Self::MySQLError(from)
    }
}
impl From<PasswordError> for DatabaseError {
    fn from(from: PasswordError) -> Self {
        Self::PasswordError(from)
    }
}
impl From<UsernameError> for DatabaseError {
    fn from(from: UsernameError) -> Self {
        Self::UsernameError(from)
    }
}
impl From<JoinError> for DatabaseError{
    fn from(from: JoinError) -> Self {
        Self::JoinError(from)
    }
}
impl From<publicsuffix::errors::Error> for DatabaseError{
    fn from(from: publicsuffix::errors::Error) -> Self {
        Self::EmailError(format!("{}", from))
    }
}
impl Display for DatabaseError {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        <Self as Debug>::fmt(self, f)
    }
}
impl Error for DatabaseError {
    fn cause(&self) -> Option<&dyn Error> {
        match self {
            Self::MySQLError(error) => Some(error),
            Self::PasswordError(error) => Some(error),
            Self::UsernameError(error) => Some(error),
            Self::JoinError(error) => Some(error),
            Self::EmailError(_) => None,
            Self::NoResults => None,
        }
    }
}

pub const MAX_USERNAME_LENGTH: usize = 32;
lazy_static! {
    pub static ref VALID_USERNAME_CHARS: Vec<char> = username_valid_chars();
    pub static ref VALID_SEARCH_USERNAME_CHARS: Vec<char> = username_valid_chars().into_iter().chain(['*', '%'].iter().cloned()).collect();
}
fn username_valid_chars() -> Vec<char> {
    ('a'..='z')
        .collect::<Vec<char>>()
        .into_iter()
        .chain('A'..='Z')
        .chain('0'..='9')
        .chain(['_', '-'].iter().cloned())
        .collect()
}

pub type UsernameResult<T> = Result<T, UsernameError>;

#[derive(Debug, Eq, PartialEq, Copy, Clone)]
pub enum UsernameError {
    TooLong { length: usize, max_length: usize },
    InvalidChar(char),
}

impl Display for UsernameError {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        <Self as Debug>::fmt(self, f)
    }
}

impl Error for UsernameError {}

fn take_from_row<T: FromValue>(index: usize, mut row: Row) -> Result<(T, Row), FromRowError> {
    match row.take(index) {
        Some(val) => Ok((val, row)),
        None => return Err(FromRowError(row))
    }
}
