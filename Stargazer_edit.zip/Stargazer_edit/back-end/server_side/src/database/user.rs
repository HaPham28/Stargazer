use mysql::{FromRowError, Row};
use mysql::prelude::FromRow;
use packet::{IdType, UserPublic, UserFull, UsernameOrId, UsernameOrIdRef};
use crate::database::take_from_row;

#[derive(Debug, Clone, Default, Eq, PartialEq)]
pub struct DatabaseUser {
    pub id: IdType,
    pub username: String,
    pub password_hash: String,
    pub email: String,
    pub review_count: usize,
}
impl From<&DatabaseUser> for UsernameOrId{
    fn from(from: &DatabaseUser) -> Self {
        Self::Id(from.id)
    }
}
impl<'a> From<&'a DatabaseUser> for UsernameOrIdRef<'a>{
    fn from(from: &'a DatabaseUser) -> Self {
        Self::Id(from.id)
    }
}
impl From<DatabaseUser> for UserPublic {
    fn from(from: DatabaseUser) -> Self {
        Self{
            id: from.id,
            username: from.username,
            review_count: from.review_count,
        }
    }
}
impl From<DatabaseUser> for UserFull{
    fn from(from: DatabaseUser) -> Self {
        Self{
            user: UserPublic{
                id: from.id,
                username: from.username,
                review_count: from.review_count,
            },
            email: from.email,
        }
    }
}
impl FromRow for DatabaseUser {
    fn from_row_opt(row: Row) -> Result<Self, FromRowError> where Self: Sized {
        let (id, row) = take_from_row(0, row)?;
        let (username, row) = take_from_row(1, row)?;
        let (password_hash, row) = take_from_row(2, row)?;
        let (email, row) = take_from_row(3, row)?;
        let (num_reviews, _) = take_from_row(4, row)?;
        Ok(Self { id, username, password_hash, email, review_count: num_reviews })
    }
}
