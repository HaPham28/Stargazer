use std::io::{Read, Write};
use std::io;

pub struct RemoteReader<'a, R: Read>(&'a mut R);
impl<'a, R: Read> RemoteReader<'a, R>{
    pub fn from_reader(reader: &'a mut R) -> Self{
        Self{
            0: reader,
        }
    }
}
impl<'a, R: Read> Read for RemoteReader<'a, R>{
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        self.0.read(buf)
    }
}
impl<'a, R: Read> From<&'a mut R> for RemoteReader<'a, R>{
    fn from(from: &'a mut R) -> Self {
        Self::from_reader(from)
    }
}

pub struct RemoteWriter<'a, W: Write>(&'a mut W);
impl<'a, W: Write> RemoteWriter<'a, W>{
    pub fn from_writer(writer: &'a mut W) -> Self{
        Self{
            0: writer,
        }
    }
}
impl<'a, W: Write> Write for RemoteWriter<'a, W>{
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        self.0.write(buf)
    }

    fn flush(&mut self) -> io::Result<()> {
        self.0.flush()
    }
}
impl<'a, W: Write> From<&'a mut W> for RemoteWriter<'a, W>{
    fn from(from: &'a mut W) -> Self {
        Self::from_writer(from)
    }
}
