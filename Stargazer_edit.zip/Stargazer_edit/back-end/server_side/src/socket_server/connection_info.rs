use std::net::SocketAddr;
use crate::socket_server::buffer::Buffer;

pub struct ConnectionInfo<'a>{
    pub address: &'a SocketAddr,
    pub data_buffer: Buffer,
    pub state: ConnectionState,
}
impl<'a> ConnectionInfo<'a>{
    pub fn new(address: &'a SocketAddr) -> Self{
        Self{
            address,
            data_buffer: Default::default(),
            state: ConnectionState::Ready
        }
    }
}

#[derive(Copy, Clone, Debug)]
pub enum ConnectionState{
    Ready,
    ReadingPacket(usize),
}
