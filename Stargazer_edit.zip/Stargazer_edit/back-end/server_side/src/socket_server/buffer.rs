use std::collections::VecDeque;
use std::io::Read;
use std::io::Write;
use std::io as std_io;
use std::cmp::min;
use tokio::prelude::{AsyncRead, AsyncWrite};
use std::task::Context;
use tokio::macros::support::{Pin, Poll};
use tokio::io as tokio_io;
use std::ops::RangeBounds;

///Reads from the front
#[derive(Debug, Default, Clone)]
pub struct Buffer(VecDeque<u8>);
impl Buffer{
    pub fn new() -> Self{
        Self{
            0: Default::default(),
        }
    }

    pub fn drain<'a, R: RangeBounds<usize>>(&'a mut self, range: R) -> impl Iterator<Item=u8> + 'a{
        self.0.drain(range)
    }

    pub fn len(&self) -> usize{
        self.0.len()
    }

    pub fn write_front(&mut self, data: &[u8]){
        for &val in data{
            self.0.push_front(val);
        }
    }
}
impl Read for Buffer{
    fn read(&mut self, buf: &mut [u8]) -> std_io::Result<usize> {
        let size = min(self.0.len(), buf.len());
        for (index, byte) in self.0.drain(0..size).enumerate(){
            buf[index] = byte;
        }
        Ok(size)
    }
}
impl Write for Buffer{
    fn write(&mut self, buf: &[u8]) -> std_io::Result<usize> {
        for &byte in buf{
            self.0.push_back(byte);
        }
        Ok(buf.len())
    }

    fn flush(&mut self) -> std_io::Result<()> {
        Ok(())
    }
}
impl AsyncRead for Buffer{
    fn poll_read(self: Pin<&mut Self>, _cx: &mut Context<'_>, buf: &mut [u8]) -> Poll<tokio_io::Result<usize>> {
        let size = min(self.0.len(), buf.len());
        for (index, byte) in self.get_mut().0.drain(0..size).enumerate(){
            buf[index] = byte;
        }
        Poll::Ready(Ok(size))
    }
}
impl AsyncWrite for Buffer{
    fn poll_write(self: Pin<&mut Self>, _cx: &mut Context<'_>, buf: &[u8]) -> Poll<Result<usize, tokio_io::Error>> {
        match self.get_mut().write(buf) {
            Ok(value) => Poll::Ready(Ok(value)),
            Err(error) => Poll::Ready(Err(error)),
        }
    }

    fn poll_flush(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Result<(), tokio_io::Error>> {
        match self.get_mut().flush(){
            Ok(_) => Poll::Ready(Ok(())),
            Err(error) => Poll::Ready(Err(error))
        }

    }

    fn poll_shutdown(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Result<(), tokio_io::Error>> {
        Poll::Ready(Ok(()))
    }
}


