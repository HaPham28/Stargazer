mod auth_token_registry;
mod buffer;
mod connection_info;
mod packet_handler;

use std::{io, fmt};
use std::error::Error;
use packet::{PORT, FromServerWrapper, ResponseError};
use std::fmt::{Debug, Formatter};
use std::net::Ipv4Addr;
use crate::socket_server::packet_handler::{PacketHandler, PacketError};
use std::sync::Arc;
use warp::{Filter, Rejection};
use rsa::{RSAPrivateKey, RSAPublicKey};
use rand::thread_rng;
use warp::reject::Reject;
use hyper::StatusCode;
use std::convert::Infallible;

const ADDRESS: Ipv4Addr = Ipv4Addr::new(0, 0, 0, 0);
const NUM_THREADS: usize = 32;

pub struct SocketServer{
    packet_handler: PacketHandler,
    key_pair: (RSAPrivateKey, RSAPublicKey),
}
impl SocketServer{
    pub async fn new() -> SocketServerResult<Self>{
        Ok(Self{
            packet_handler: PacketHandler::new()?,
            key_pair: Self::get_key()?,
        })
    }

    pub async fn server_function<'a>(self) -> SocketServerResult<()>{
        let self_access = Arc::new(self);
        let self_filter = warp::any().map(move || self_access.clone());
        let packet_route = warp::path!("packet")
            .and(warp::post())
            .and(warp::body::json())
            .and(warp::body::content_length_limit(1 << 15))
            .and(self_filter.clone())
            .and_then(|data, self_access| Self::handle_packet(self_access, data))
            // .map(|body: KeyWithData, self_access: Arc<Self>| warp::reply::json(&KeyWithData{
            //     key: self_access.key_pair.1.clone(),
            //     data: body.key.encrypt(
            //         &mut thread_rng(),
            //         PaddingScheme::PKCS1v15Encrypt,
            //         &serde_cbor::to_vec(&FromServerWrapper{
            //             client_id: 100,
            //             packet: Err(ResponseError::Unimplemented)
            //         }).unwrap()
            //     ).unwrap()
            // }))
        ;
        let key_route = warp::path!("key")
            .and(warp::get())
            .and(self_filter.clone())
            .map(|self_access: Arc<SocketServer>| Ok(warp::reply::json(&self_access.key_pair.1)));

        warp::serve(packet_route
            .or(key_route)
            .recover(Self::handle_rejection)
            .with(warp::cors::cors()
                .allow_any_origin()
                .allow_method("GET")
                .allow_method("POST")
                .allow_header("content-type")
            )
            .with(warp::log::log("Server Log"))
        ).run((ADDRESS, PORT)).await;
        Ok(())
    }

    async fn handle_rejection(err: Rejection) -> Result<impl warp::Reply, Infallible>{
        eprintln!("Error: {:?}", err);
        if let Some(reason) = err.find::<SocketServerError>(){
            let packet_out = FromServerWrapper{
                client_id: 0,
                packet: Err(ResponseError::InternalError(format!("Error: {:?}", reason)))
            };
            Ok(warp::reply::with_status(serde_json::to_string(&serde_cbor::to_vec(&packet_out).unwrap()).unwrap(), StatusCode::INTERNAL_SERVER_ERROR))
        }
        else{
            let packet_out = FromServerWrapper{
                client_id: 0,
                packet: Err(ResponseError::InternalError(format!("Unknown error internal error: {:?}", err)))
            };
            Ok(warp::reply::with_status(
                serde_json::to_string(&serde_cbor::to_vec(&packet_out).unwrap()).unwrap(), StatusCode::INTERNAL_SERVER_ERROR))
        }
    }

    async fn handle_packet(self_access: Arc<Self>, packet: Vec<u8>) -> Result<impl warp::Reply, warp::Rejection> {
         Ok(Self::get_return_packet(&self_access, &packet).await?)
    }
    async fn get_return_packet(self_access: &Arc<Self>, packet: &Vec<u8>) -> SocketServerResult<impl warp::Reply>{
        let from_client = serde_cbor::from_slice(packet.as_slice())?;
        let packet_return = self_access.packet_handler.handle_packet(from_client).await?;
        let data = serde_cbor::to_vec(&packet_return)?;

        Ok(warp::reply::json(&data))
    }

    //noinspection DuplicatedCode
    fn get_key() -> SocketServerResult<(RSAPrivateKey, RSAPublicKey)>{
        let mut rng = thread_rng();
        const BITS: usize = 128;
        let priv_key = RSAPrivateKey::new(&mut rng, BITS)?;
        let pub_key = RSAPublicKey::from(&priv_key);
        Ok((priv_key, pub_key))
    }

}

pub type SocketServerResult<T> = Result<T, SocketServerError>;
#[derive(Debug)]
pub enum SocketServerError{
    IoError(io::Error),
    PacketError(PacketError),
    SerdeCborError(serde_cbor::Error),
    RSAError(rsa::errors::Error),
}
impl From<io::Error> for SocketServerError{
    fn from(from: io::Error) -> Self {
        Self::IoError(from)
    }
}
impl From<PacketError> for SocketServerError{
    fn from(from: PacketError) -> Self {
        Self::PacketError(from)
    }
}
impl From<serde_cbor::Error> for SocketServerError{
    fn from(from: serde_cbor::Error) -> Self {
        Self::SerdeCborError(from)
    }
}
impl From<rsa::errors::Error> for SocketServerError{
    fn from(from: rsa::errors::Error) -> Self {
        Self::RSAError(from)
    }
}
impl fmt::Display for SocketServerError{
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        <Self as Debug>::fmt(self, f)
    }
}
impl Error for SocketServerError{
    fn cause(&self) -> Option<&dyn Error> {
        match self {
            SocketServerError::IoError(error) => Some(error),
            SocketServerError::PacketError(error) => Some(error),
            SocketServerError::SerdeCborError(error) => Some(error),
            SocketServerError::RSAError(error) => Some(error),
        }
    }
}
impl From<SocketServerError> for warp::Rejection{
    fn from(from: SocketServerError) -> Self {
        eprintln!("Here: {}", from);
        warp::reject::custom(from)
    }
}
impl Reject for SocketServerError{}
