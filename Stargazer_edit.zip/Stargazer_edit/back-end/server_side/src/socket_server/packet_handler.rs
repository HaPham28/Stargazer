use crate::database::{DatabaseManager, DatabaseError};
use std::fmt;
use mysql::serde::export::Formatter;
use mysql::serde::export::fmt::Debug;
use std::error::Error;
use crate::database::prepared_statements::PreparedStatements;
use crate::password::{verify_password, PasswordError, hash_password};
use pbkdf2::CheckError;
use ::packet::*;
use std::sync::atomic::AtomicUsize;
use std::sync::atomic::Ordering::SeqCst;
use warp::reject::Reject;
use crate::socket_server::auth_token_registry::AuthTokenRegistry;
use ::packet::data::place::Place;

const MAX_CONCURRENT: usize = 16;

#[derive(Debug)]
pub struct PacketHandler {
    database_manager: DatabaseManager,
    statements: Vec<PreparedStatements>,
    statements_index: AtomicUsize,
    auth_tokens: AuthTokenRegistry,
}
impl PacketHandler {
    pub fn new() -> PacketResult<Self> {
        let manager = DatabaseManager::new()?;
        let mut statements = Vec::with_capacity(MAX_CONCURRENT);
        for _ in 0..MAX_CONCURRENT {
            statements.push(manager.prepare_statements()?);
        }

        Ok(Self {
            database_manager: manager,
            statements,
            statements_index: AtomicUsize::new(0),
            auth_tokens: Default::default(),
        })
    }

    pub async fn handle_packet(&self, packet: FromClientWrapper) -> PacketResult<FromServerWrapper> {
        let statements = self.statements.get(self.statements_index.fetch_add(1, SeqCst) % self.statements.len()).unwrap();
        Ok(FromServerWrapper {
            client_id: packet.client_id,
            packet: match packet.packet {
                PacketFromClient::LoginRequest { username, password } => self.handle_login(statements, username, password).await?,
                PacketFromClient::ChangePasswordRequest { username, old_password, new_password } => self.handle_change_password(statements, username, old_password, new_password).await?,
                PacketFromClient::RegisterRequest { username, email, password } => self.handle_register(statements, username, email, password).await?,
                PacketFromClient::DeleteUserRequest { username, password } => self.handle_delete_user(statements, username, password).await?,

                PacketFromClient::UserPublicRequest { user } => self.handle_user_public(statements, user).await?,
                PacketFromClient::UserFullRequest { token } => self.handle_user_full(token).await?,
                PacketFromClient::SearchUserRequest { search_string, paging } => self.handle_search_user(statements, search_string, paging).await?,

                PacketFromClient::GetPlaceRequest { place_id } => self.handle_place(statements, place_id).await?,

                PacketFromClient::AddReviewRequest { token, place_id, review, review_text } => self.handle_add_review(statements, token, place_id, review, review_text).await?,
                PacketFromClient::DeleteReviewRequest { token, review_id } => self.handle_delete_review(statements, token, review_id).await?,
                PacketFromClient::GetReviewRequest { review_id } => self.handle_get_review(statements, review_id).await?,
                PacketFromClient::GetReviewsForUserRequest { user, paging } => self.handle_get_reviews_for_user(statements, user, paging).await?,
                PacketFromClient::GetReviewsForPlaceRequest { place_id, paging } => self.handle_get_reviews_for_place(statements, place_id, paging).await?,

                PacketFromClient::AddFavoritePlaceRequest { token, place_id } => self.handle_add_favorite_place(statements, token, place_id).await?,
                PacketFromClient::RemoveFavoritePlaceRequest { token, place_id } => self.handle_remove_favorite_place(statements, token, place_id).await?,
                PacketFromClient::GetFavoritePlacesRequest { token, paging } => self.handle_get_favorite_places(statements, token, paging).await?,
            },
        })
    }


    async fn handle_login(&self, statements: &PreparedStatements, username: String, password: String) -> HandleOutput {
        let user = match statements.get_user(UsernameOrIdRef::Username(&username)).await? {
            Some(value) => value,
            None => return Ok(Err(AuthError::Failed.into())),
        };
        match verify_password(&password, &user.password_hash) {
            Ok(_) => Ok(Ok(PacketFromServer::LoginResponse {
                auth_token: self.auth_tokens.generate_auth_token(user.clone()).await,
                user: user.into(),
            })),
            Err(error) => {
                match error {
                    PasswordError::CheckError(CheckError::HashMismatch) => Ok(Err(AuthError::Failed.into())),
                    error => Err(error.into())
                }
            }
        }
    }
    async fn handle_change_password(&self, statements: &PreparedStatements, username: String, old_password: String, new_password: String) -> HandleOutput {
        let user = match statements.get_user(UsernameOrIdRef::Username(&username)).await? {
            None => return Ok(Err(AuthError::Failed.into())),
            Some(value) => value
        };
        match verify_password(&old_password, &user.password_hash) {
            Ok(_) => {
                statements.change_user_password(user.id, &hash_password(&new_password)?).await?;
                Ok(Ok(PacketFromServer::ChangePasswordResponse {
                    auth_token: self.auth_tokens.generate_auth_token(user.clone()).await,
                    user: user.into(),
                }))
            }
            Err(error) => {
                match error {
                    PasswordError::CheckError(CheckError::HashMismatch) => Ok(Err(AuthError::Failed.into())),
                    error => Err(error.into())
                }
            }
        }
    }
    async fn handle_register(&self, statements: &PreparedStatements, username: String, email: String, password: String) -> HandleOutput {
        let username_check = statements.get_user(UsernameOrIdRef::Username(&username));
        let email_check = statements.get_user_by_email(&email);
        if let Some(_) = username_check.await? {
            return Ok(Err(RegisterError::UsernameTaken { username }.into()));
        };
        if let Some(_) = email_check.await? {
            return Ok(Err(RegisterError::EmailTaken { email }.into()));
        }
        let password_hash = hash_password(&password)?;
        let user = statements.insert_user(&username, &password_hash, &email).await?;
        Ok(Ok(PacketFromServer::RegisterResponse {
            token: self.auth_tokens.generate_auth_token(user.clone()).await,
            user: user.into(),
        }))
    }
    async fn handle_delete_user(&self, statements: &PreparedStatements, username: String, password: String) -> HandleOutput {
        let user = match statements.get_user(UsernameOrIdRef::Username(&username)).await? {
            None => return Ok(Err(AuthError::Failed.into())),
            Some(value) => value
        };
        match verify_password(&password, &user.password_hash) {
            Ok(_) => {
                statements.delete_user((&user).into()).await?;
                Ok(Ok(PacketFromServer::DeleteUserResponse))
            }
            Err(error) => {
                match error {
                    PasswordError::CheckError(CheckError::HashMismatch) => Ok(Err(AuthError::Failed.into())),
                    error => Err(error.into())
                }
            }
        }
    }

    async fn handle_user_public(&self, statements: &PreparedStatements, user: UsernameOrId) -> HandleOutput {
        Ok(Ok(PacketFromServer::UserPublicResponse {
            user: match statements.get_user((&user).into()).await? {
                None => return Ok(Err(ResponseError::NoData)),
                Some(value) => value.into(),
            }
        }))
    }
    async fn handle_user_full(&self, token: TokenType) -> HandleOutput {
        match self.auth_tokens.verify_auth_token(&token).await {
            Ok((new_token, user)) => Ok(Ok(PacketFromServer::UserFullResponse {
                new_token,
                user: user.into(),
            })),
            Err(auth_error) => Ok(Err(auth_error.into())),
        }
    }
    async fn handle_search_user(&self, statements: &PreparedStatements, search_string: SearchString, paging: Paging) -> HandleOutput {
        let found = statements.search_for_user_by_username(&search_string.0, paging).await?;
        Ok(Ok(PacketFromServer::SearchUserResponse {
            found: found.into_iter().map(|user| user.into()).collect(),
        }))
    }

    async fn handle_place(&self, statements: &PreparedStatements, place_id: String) -> HandleOutput {
        Ok(Ok(PacketFromServer::GetPlaceResponse {
            place: statements.get_place(place_id).await?.into(),
        }))
    }

    async fn handle_add_review(&self, statements: &PreparedStatements, token: TokenType, place_id: String, review: u8, review_text: Option<String>) -> HandleOutput {
        match self.auth_tokens.verify_auth_token(&token).await {
            Ok((new_token, user)) => {
                let review = statements.insert_review(user.id, place_id, review, review_text).await?;
                Ok(Ok(PacketFromServer::AddReviewResponse {
                    new_token,
                    id: review.id,
                }))
            }
            Err(auth_error) => Ok(Err(auth_error.into())),
        }
    }
    async fn handle_delete_review(&self, statements: &PreparedStatements, token: TokenType, review_id: IdType) -> HandleOutput {
        match self.auth_tokens.verify_auth_token(&token).await {
            Ok((new_token, user)) => {
                let review = statements.get_review(review_id).await?;
                if review.user_id != user.id {
                    return Err(PacketError::Unauthorized(Some(new_token)));
                }
                statements.delete_review(review_id).await?;
                Ok(Ok(PacketFromServer::DeleteReviewResponse {
                    new_token,
                }))
            }
            Err(auth_error) => Ok(Err(auth_error.into())),
        }
    }
    async fn handle_get_review(&self, statements: &PreparedStatements, review_id: IdType) -> HandleOutput{
        Ok(Ok(PacketFromServer::GetReviewResponse {
            review: statements.get_review(review_id).await?.into(),
        }))
    }
    async fn handle_get_reviews_for_user(&self, statements: &PreparedStatements, user: UsernameOrId, paging: Paging) -> HandleOutput{
        Ok(Ok(PacketFromServer::GetReviewsForUserResponse {
            reviews: statements.get_reviews_for_user((&user).into(), paging).await?.into_iter()
                .map(|review| review.into())
                .collect(),
        }))
    }
    async fn handle_get_reviews_for_place(&self, statements: &PreparedStatements, place_id: String, paging: Paging) -> HandleOutput{
        Ok(Ok(PacketFromServer::GetReviewsForPlaceResponse {
            reviews: statements.get_reviews_for_place(place_id, paging).await?.into_iter()
                .map(|review| review.into())
                .collect(),
        }))
    }

    async fn handle_add_favorite_place(&self, statements: &PreparedStatements, token: TokenType, place_id: String) -> HandleOutput{
        match self.auth_tokens.verify_auth_token(&token).await {
            Ok((new_token, user)) => {
                statements.insert_favorite_place(user.id, place_id).await?;
                Ok(Ok(PacketFromServer::AddFavoritePlaceResponse {
                    new_token,
                }))
            },
            Err(auth_error) => Ok(Err(auth_error.into())),
        }
    }
    async fn handle_remove_favorite_place(&self, statements: &PreparedStatements, token: TokenType, place_id: String) -> HandleOutput{
        match self.auth_tokens.verify_auth_token(&token).await {
            Ok((new_token, user)) => {
                statements.delete_favorite_place(user.id, place_id).await?;
                Ok(Ok(PacketFromServer::RemoveFavoritePlaceResponse {
                    new_token,
                }))
            },
            Err(auth_error) => Ok(Err(auth_error.into())),
        }
    }
    async fn handle_get_favorite_places(&self, statements: &PreparedStatements, token: TokenType, paging: Paging) -> HandleOutput{
        match self.auth_tokens.verify_auth_token(&token).await {
            Ok((new_token, user)) => {
                let places = statements.get_favorite_places(user.id, paging).await?
                    .into_iter()
                    .map(|place| Place::from(place))
                    .collect();
                Ok(Ok(PacketFromServer::GetFavoritePlacesResponse {
                    new_token,
                    places,
                }))
            },
            Err(auth_error) => Ok(Err(auth_error.into())),
        }
    }
}

type HandleOutput = PacketResult<ResponseResult<PacketFromServer>>;

pub type PacketResult<T> = Result<T, PacketError>;
#[derive(Debug)]
pub enum PacketError {
    DatabaseError(DatabaseError),
    PasswordError(PasswordError),
    Unauthorized(Option<AuthToken>),
    Unimplemented,
}
impl From<DatabaseError> for PacketError {
    fn from(from: DatabaseError) -> Self {
        Self::DatabaseError(from)
    }
}
impl From<PasswordError> for PacketError {
    fn from(from: PasswordError) -> Self {
        Self::PasswordError(from)
    }
}
impl fmt::Display for PacketError {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        <Self as Debug>::fmt(self, f)
    }
}
impl Error for PacketError {
    fn cause(&self) -> Option<&dyn Error> {
        match self {
            Self::DatabaseError(error) => Some(error),
            Self::PasswordError(error) => Some(error),
            Self::Unimplemented | Self::Unauthorized(_) => None,
        }
    }
}
impl From<PacketError> for warp::Rejection {
    fn from(from: PacketError) -> Self {
        warp::reject::custom(from)
    }
}
impl Reject for PacketError {}
