use crate::AsyncMutex;
use bimap::BiHashMap;
use packet::{TokenType, AuthToken, AuthResult, AuthError, IdType};
use crate::database::user::DatabaseUser;
use rand::random;
use std::ops::DerefMut;
use mysql::chrono::{Utc, DateTime, Duration};
use lazy_static::lazy_static;
use std::hash::{Hash, Hasher};

lazy_static! {
    pub static ref TOKEN_LIFETIME: Duration = Duration::minutes(30);
}

#[derive(Debug, Default)]
pub struct AuthTokenRegistry{
    auth_tokens: AsyncMutex<BiHashMap<TokenType, TokenInfo>>,
}
impl AuthTokenRegistry{
    pub fn new() -> Self{
        Self{
            auth_tokens: Default::default(),
        }
    }

    pub async fn generate_auth_token(&self, user: DatabaseUser) -> AuthToken {
        Self::generate_auth_token_map_ref(self.auth_tokens.lock().await.deref_mut(), user)
    }
    fn generate_auth_token_map_ref(map: &mut BiHashMap<TokenType, TokenInfo>, user: DatabaseUser) -> AuthToken {
        let token_info = TokenInfo::new(user);
        if map.contains_right(&token_info) {
            map.remove_by_right(&token_info);
        }

        let mut token = random();
        while map.contains_left(&token) {
            token = random();
        }

        let expires = Some(token_info.expires.clone());
        map.insert(token, token_info);
        AuthToken {
            token,
            expires,
        }
    }

    pub async fn verify_auth_token(&self, token: &TokenType) -> AuthResult<(AuthToken, DatabaseUser)> {
        Self::verify_auth_token_map_ref(self.auth_tokens.lock().await.deref_mut(), token)
    }
    fn verify_auth_token_map_ref(map: &mut BiHashMap<TokenType, TokenInfo>, token: &TokenType) -> AuthResult<(AuthToken, DatabaseUser)> {
        let user_id = match map.get_by_left(&token) {
            None => return Err(AuthError::Failed),
            Some(user) => if user.expires > Utc::now() {
                user.user.id
            } else {
                return Err(AuthError::TokenExpired);
            },
        };

        let mut token = random();
        while map.contains_left(&token) {
            token = random();
        }

        let expires = Some(Utc::now() + *TOKEN_LIFETIME);
        let mut entry = map.remove_by_right(&TokenInfo::from_id(user_id)).unwrap();
        entry.0 = token;
        entry.1.expires = expires.clone().unwrap();
        let user = entry.1.user.clone();
        map.insert(entry.0, entry.1);
        Ok((AuthToken {
            token,
            expires,
        }, user))
    }
}

#[derive(Debug)]
struct TokenInfo {
    user: DatabaseUser,
    expires: DateTime<Utc>,
}
impl TokenInfo {
    pub fn new(user: DatabaseUser) -> Self {
        Self {
            user,
            expires: Utc::now() + *TOKEN_LIFETIME,
        }
    }

    pub fn from_id(id: IdType) -> Self {
        Self {
            user: DatabaseUser {
                id,
                ..Default::default()
            },
            expires: Utc::now(),
        }
    }
}
impl PartialEq for TokenInfo {
    fn eq(&self, other: &Self) -> bool {
        self.user.id.eq(&other.user.id)
    }
}
impl Eq for TokenInfo {}
impl Hash for TokenInfo {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.user.id.hash(state)
    }
}
