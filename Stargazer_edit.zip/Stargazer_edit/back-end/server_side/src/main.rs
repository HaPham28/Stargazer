#![allow(dead_code)]

mod credentials;
mod database;
mod password;
mod socket_server;

mod read_write_help;

pub(crate) use tokio::sync::Mutex as AsyncMutex;
use crate::socket_server::SocketServer;
use flexi_logger::{Logger, LogSpecification, LevelFilter, Duplicate};

#[tokio::main]
async fn main() {
    Logger::with(LogSpecification::default(LevelFilter::Trace).finalize())
        .log_to_file()
        .duplicate_to_stderr(Duplicate::Info)
        .start()
        .expect("Could not init logger");
    println!("Starting server...");
    let socket_server = SocketServer::new().await.expect("Socket server creation error");
    println!("Server built");
    let server = socket_server.server_function();
    println!("Server started");
    server.await.expect("Server function error");
    println!("Server finished");
}
