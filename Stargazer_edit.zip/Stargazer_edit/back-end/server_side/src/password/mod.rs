use std::error::Error;
use std::fmt;
use std::fmt::{Display, Debug};

use mysql::serde::export::Formatter;
use pbkdf2::{CheckError, pbkdf2_check, pbkdf2_simple};

use crate::password::pepper::PEPPER;

mod pepper;

pub const CHARSET: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789)(*&^%$#@!~";
pub const WORK_FACTOR: u8 = 10;
pub const MIN_LENGTH: usize = 8;

pub fn verify_password(password: &str, hash: &str) -> PasswordResult<()> {
    pbkdf2_check(&(password.to_owned() + PEPPER), hash)?;
    Ok(())
}

pub fn hash_password(password: &str) -> PasswordResult<String> {
    check_password_valid(password)?;
    Ok(pbkdf2_simple(&(password.to_owned() + PEPPER), 1 << WORK_FACTOR)?)
}

fn check_password_valid(password: &str) -> PasswordResult<()> {
    if password.len() < MIN_LENGTH {
        return Err(PasswordError::TooShort { length: password.len(), min_length: MIN_LENGTH });
    }
    Ok(())
}

pub type PasswordResult<T> = Result<T, PasswordError>;

#[derive(Debug)]
pub enum PasswordError {
    RandError(rand_core::Error),
    CheckError(CheckError),
    TooShort { length: usize, min_length: usize },
}

impl From<rand_core::Error> for PasswordError {
    fn from(from: rand_core::Error) -> Self {
        Self::RandError(from)
    }
}

impl From<CheckError> for PasswordError {
    fn from(from: CheckError) -> Self {
        Self::CheckError(from)
    }
}

impl Display for PasswordError {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        <Self as Debug>::fmt(self, f)
    }
}

impl Error for PasswordError {
    fn cause(&self) -> Option<&dyn Error> {
        match self {
            Self::RandError(error) => Some(error),
            Self::CheckError(_) => None,
            Self::TooShort { .. } => None,
        }
    }
}

#[cfg(test)]
pub mod test {
    use std::str::from_utf8;

    use rand::{Rng, thread_rng};
    use rand::prelude::ThreadRng;

    use crate::password::CHARSET;

    pub fn gen_password(rng: &mut ThreadRng) -> String {
        let length = rng.gen_range(8, 33);
        let mut out = vec![0; length];
        for char in out.iter_mut() {
            *char = CHARSET[rng.gen_range(0, CHARSET.len())];
        }
        from_utf8(out.as_slice()).unwrap().into()
    }

    #[test]
    fn gen_passwords() {
        let mut rng = thread_rng();
        for _ in 0..1 << 10 {
            println!("{}", gen_password(&mut rng));
        }
    }
}
