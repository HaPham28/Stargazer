use std::env::current_dir;
use std::fs::*;
use std::io::{Read, Write};

use inflector::cases::pascalcase::to_pascal_case;

struct Credential {
    account_id: String,
    username: String,
    password: String,
}

fn main() {
    build_credentials();
    // build_statements();
    add_pepper();
}

fn write_to_file(file: &mut File, data: &str) {
    let bytes = data.as_bytes();
    let mut index = 0;
    while index < bytes.len() {
        index += file.write(&bytes[index..]).unwrap();
    }
}

fn build_credentials() {
    let mut credentials_path = current_dir().unwrap();
    credentials_path.push("password_files");
    credentials_path.push("credentials.json");
    println!("cargo:rerun-if-changed={}", credentials_path.to_str().unwrap());
    let json: serde_json::Value = serde_json::from_reader(File::open(credentials_path).unwrap()).unwrap();

    let credentials: Vec<_> = json
        .as_object().unwrap()
        .iter()
        .map(|(key, value)| {
            Credential {
                account_id: String::from(key),
                username: value.get("username").unwrap().as_str().unwrap().to_owned(),
                password: value.get("password").unwrap().as_str().unwrap().to_owned(),
            }
        })
        .collect();

    create_dir_all("src/credentials").unwrap();
    for file in read_dir("src/credentials").unwrap().map(|file| file.unwrap()) {
        let file_name = file.file_name().into_string().unwrap();
        if file_name.contains(".rs") {
            remove_file(format!("src/credentials/{}", file_name)).unwrap();
        }
    }

    let mut credentials_module = OpenOptions::new()
        .write(true)
        .create(true)
        .open("src/credentials/mod.rs")
        .unwrap();

    for credential in &credentials {
        write_to_file(&mut credentials_module, &format!("pub mod {};\n", credential.account_id));
        write_to_file(
            &mut OpenOptions::new()
                .write(true)
                .create(true)
                .open(format!("src/credentials/{}.rs", credential.account_id))
                .unwrap(),
            &format!(
                "#![allow(dead_code)]\npub const USERNAME: &'static str = \"{}\";\npub const PASSWORD: &'static str = \"{}\";",
                credential.username,
                credential.password
            ),
        );
    }

    write_to_file(&mut credentials_module, "\n\
    #[allow(dead_code)]\n\
    #[derive(Copy, Clone, Debug, Eq, PartialEq)]\n\
    pub enum DatabaseUser{\n\
    ");
    for credential in &credentials {
        write_to_file(&mut credentials_module, &format!("    {},\n", to_pascal_case(&credential.account_id)));
    }
    write_to_file(&mut credentials_module, "}");
}

fn add_pepper() {
    let mut pepper_path = current_dir().unwrap();
    pepper_path.push("password_files");
    pepper_path.push("pepper");
    println!("cargo:rerun-if-changed={}", pepper_path.to_str().unwrap());
    let mut pepper = String::new();
    File::open(pepper_path).unwrap().read_to_string(&mut pepper).unwrap();

    let mut pepper_src = current_dir().unwrap();
    pepper_src.push("src");
    pepper_src.push("password");
    pepper_src.push("pepper.rs");
    if pepper_src.exists() {
        remove_file(&pepper_src).unwrap();
    }
    write_to_file(&mut OpenOptions::new().write(true).create(true).open(pepper_src).unwrap(), &format!("pub(super) const PEPPER: &'static str = \"{}\";", pepper));
}

// struct Statement{
//     file_name: String,
//     account_id: String,
//     parameters: BTreeMap<String, String>,
// }
// fn build_statements(){
//     let mut statements_path = current_dir().unwrap();
//     statements_path.push("sql");
//     statements_path.push("statements.json");
//     println!("cargo:rerun-if-changed={}", statements_path.to_str().unwrap());
//
//     let json: serde_json::Value = serde_json::from_reader(File::open(statements_path).unwrap()).unwrap();
//     let statements: Vec<_> = json
//         .as_object().unwrap().iter()
//         .map(|(key, value)|{
//             Statement{
//                 file_name: key.to_owned(),
//                 account_id: value.get("account_id").unwrap().as_str().unwrap().to_owned(),
//                 parameters: value.get("parameters").unwrap().as_object().unwrap().iter()
//                     .map(|(key, value)|{
//                         (key.to_owned(), value.as_str().unwrap().to_owned())
//                     })
//                     .collect(),
//             }
//         })
//         .collect();
//
//     let mut statement_src_dir = current_dir().unwrap();
//     statement_src_dir.push("src");
//     statement_src_dir.push("database");
//     statement_src_dir.push("statement");
//     create_dir_all(&statement_src_dir).unwrap();
//     remove_dir_all(&statement_src_dir);
//     let mut statement_module = statement_src_dir.clone();
//     statement_module.push("mod.rs");
//     let mut statement_module = OpenOptions::new()
//         .write(true)
//         .create(true)
//         .open(statement_module)
//         .unwrap();
//
//     for statement in statements{
//         write_to_file(&mut statement_module, &format!("pub mod "))
//
//         let mut statement_src = statement_src_dir.clone();
//         statement_src.push(statement.account_id);
//     }
// }
