use serde::{Serialize, Deserialize};

#[derive(Debug, Copy, Clone, Serialize, Deserialize)]
pub struct Paging{
    pub limit: usize,
    pub offset: usize,
}
