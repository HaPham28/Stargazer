use serde::{Serialize, Deserialize};
use crate::IdType;

#[derive(Debug, Serialize, Deserialize, Default, Clone)]
pub struct Review{
    pub user_id: IdType,
    pub place_id: String,
    pub review: u8,
    pub review_text: Option<String>,
}
