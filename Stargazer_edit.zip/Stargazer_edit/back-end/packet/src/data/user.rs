use serde::{Serialize, Deserialize};

pub type IdType = usize;

#[derive(Debug, Serialize, Deserialize, Default, Clone)]
pub struct UserPublic {
    pub id: IdType,
    pub username: String,
    pub review_count: usize,
}

#[derive(Debug, Serialize, Deserialize, Default, Clone)]
pub struct UserFull{
    pub user: UserPublic,
    pub email: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub enum User{
    Public(UserPublic),
    Full(UserFull),
}
