use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Place{
    pub place_id: String,
    pub average_review: Option<f64>,
    pub review_count: usize
}
