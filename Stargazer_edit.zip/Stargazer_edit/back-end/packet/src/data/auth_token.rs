use chrono::{Utc, DateTime};
use serde::{Serialize, Deserialize};

pub type TokenType = [u64; 32];

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct AuthToken{
    pub token: TokenType,
    pub expires: Option<DateTime<Utc>>,
}
impl Default for AuthToken{
    fn default() -> Self {
        Self{
            token: Default::default(),
            expires: None,
        }
    }
}
