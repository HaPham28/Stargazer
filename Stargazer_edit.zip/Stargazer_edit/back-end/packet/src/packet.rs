use serde::{Serialize, Deserialize};
use crate::*;
use crate::data::review::Review;
use crate::data::place::Place;

#[derive(Debug, Serialize, Deserialize)]
pub enum PacketFromClient {
    //User Management
    LoginRequest { username: String, password: String },
    ChangePasswordRequest { username: String, old_password: String, new_password: String },
    RegisterRequest { username: String, email: String, password: String },
    DeleteUserRequest { username: String, password: String },

    //User Info
    UserPublicRequest { user: UsernameOrId },
    UserFullRequest { token: TokenType },
    SearchUserRequest { search_string: SearchString, paging: Paging },

    //Place Info
    GetPlaceRequest { place_id: String },

    //Reviews
    AddReviewRequest { token: TokenType, place_id: String, review: u8, review_text: Option<String> },
    DeleteReviewRequest { token: TokenType, review_id: IdType },
    GetReviewRequest { review_id: IdType },
    GetReviewsForUserRequest { user: UsernameOrId, paging: Paging },
    GetReviewsForPlaceRequest { place_id: String, paging: Paging },

    //Favorite Places
    AddFavoritePlaceRequest{ token: TokenType, place_id: String },
    RemoveFavoritePlaceRequest{ token: TokenType, place_id: String },
    GetFavoritePlacesRequest{ token: TokenType, paging: Paging },
}

#[derive(Debug, Serialize, Deserialize)]
pub enum PacketFromServer {
    //User Management
    LoginResponse { auth_token: AuthToken, user: UserFull },
    ChangePasswordResponse { auth_token: AuthToken, user: UserFull },
    RegisterResponse { token: AuthToken, user: UserFull },
    DeleteUserResponse,

    //User Info
    UserPublicResponse { user: UserPublic },
    UserFullResponse { new_token: AuthToken, user: UserFull },
    SearchUserResponse { found: Vec<UserPublic> },

    //Place Info
    GetPlaceResponse { place: Place },

    //Reviews
    AddReviewResponse { new_token: AuthToken, id: IdType },
    DeleteReviewResponse { new_token: AuthToken },
    GetReviewResponse { review: Review },
    GetReviewsForUserResponse { reviews: Vec<Review> },
    GetReviewsForPlaceResponse { reviews: Vec<Review> },

    //Favorite Places
    AddFavoritePlaceResponse{ new_token: AuthToken },
    RemoveFavoritePlaceResponse{ new_token: AuthToken },
    GetFavoritePlacesResponse{ new_token: AuthToken, places: Vec<Place> },
}

#[derive(Debug, Serialize, Deserialize)]
pub enum UsernameOrId {
    Username(String),
    Id(IdType),
}
impl<'a> From<&UsernameOrIdRef<'a>> for UsernameOrId {
    fn from(from: &UsernameOrIdRef<'a>) -> Self {
        match from {
            UsernameOrIdRef::Username(username) => Self::Username(String::from(*username)),
            UsernameOrIdRef::Id(id) => Self::Id(*id),
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub enum UsernameOrIdRef<'a> {
    Username(&'a str),
    Id(IdType),
}
impl<'a> From<&'a UsernameOrId> for UsernameOrIdRef<'a> {
    fn from(from: &'a UsernameOrId) -> Self {
        match from {
            UsernameOrId::Username(username) => Self::Username(username.as_str()),
            UsernameOrId::Id(id) => Self::Id(*id),
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SearchString(pub String);
