pub mod data;
pub mod packet;

pub use data::*;
pub use packet::*;

use serde::{Serialize, Deserialize};
use std::fmt::Display;
use serde::export::Formatter;
use serde::export::fmt::Debug;
use core::fmt;
use std::error::Error;
use std::net::Ipv4Addr;
use rsa::RSAPublicKey;

pub const SERVER_IP: Ipv4Addr = Ipv4Addr::new(70, 112, 71, 212);
pub const PORT: u16 = 18432;

#[derive(Debug, Serialize, Deserialize)]
pub struct KeyWithData{
    pub key: RSAPublicKey,
    pub data: Vec<u8>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct FromClientWrapper{
    pub client_id: IdType,
    pub packet: PacketFromClient,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct FromServerWrapper{
    pub client_id: IdType,
    pub packet: ResponseResult<PacketFromServer>,
}

pub type ResponseResult<T> = Result<T, ResponseError>;
#[derive(Debug, Serialize, Deserialize)]
pub enum ResponseError{
    AuthError(AuthError),
    RegisterError(RegisterError),
    NoData,
    Unimplemented,
    InternalError(String),
}
impl From<AuthError> for ResponseError{
    fn from(from: AuthError) -> Self {
        Self::AuthError(from)
    }
}
impl From<RegisterError> for ResponseError{
    fn from(from: RegisterError) -> Self{
        Self::RegisterError(from)
    }
}
impl Display for ResponseError{
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        <Self as Debug>::fmt(self, f)
    }
}
impl Error for ResponseError{
    fn cause(&self) -> Option<&dyn Error> {
        match self {
            ResponseError::AuthError(error) => Some(error),
            ResponseError::RegisterError(error) => Some(error),
            ResponseError::NoData => None,
            ResponseError::Unimplemented => None,
            ResponseError::InternalError(_) => None,
        }
    }
}

pub type AuthResult<T> = Result<T, AuthError>;
#[derive(Debug, Serialize, Deserialize)]
pub enum AuthError{
    Failed,
    TokenExpired,
    LackPermission(AuthToken),
}
impl Display for AuthError{
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        <Self as Debug>::fmt(self, f)
    }
}
impl Error for AuthError{}

#[derive(Debug, Serialize, Deserialize)]
pub enum RegisterError{
    UsernameTaken{username: String},
    EmailTaken{email: String},
    PasswordTooShort{length: usize, min_length: usize},
}
impl Display for RegisterError{
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        <Self as Debug>::fmt(self, f)
    }
}
impl Error for RegisterError{}
