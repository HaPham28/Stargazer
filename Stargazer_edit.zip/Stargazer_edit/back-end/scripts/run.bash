#!/bin/bash

chmod +x ../target/debug/server_side
../target/debug/server_side
