#!/bin/bash

cargo clean --manifest-path ../Cargo.toml
